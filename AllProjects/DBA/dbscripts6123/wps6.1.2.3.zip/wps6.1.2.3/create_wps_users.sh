#!/bin/sh
CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

. $CURRENT_DIR/../setEnv

$ORACLE_HOME/bin/sqlplus -s /nolog << EOF
  CONN sys/$SYS_PASSWD@$DATABASE as sysdba
  set echo on
  SPOOL ${LOGDIR}/create_wps_users.lst 

  @create_wps_users.sql 

  SPOOL off
EOF
