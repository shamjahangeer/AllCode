-- Licensed Materials - Property of IBM
-- 5724-M24
-- Copyright IBM Corporation 2007, 2008.  All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- ------------------------------------------------------------------------------------
--
-- Script file to create database and schema (tables) for Oracle 10g
--
---------------------------------------------------------------------------------------
-- Following variables need to be changed for customization before running this script: 
-- IBMBUSSP = the schema owner, eg MONITOR
-- wpcdb = the schema owner password
-- RMDEFAULTTS32S = the directory or prefix for tablespace datafiles, eg DEFAULTTS
--
-- Run the script in SQL*Plus.
--
-- USAGE:  sqlplus system/passw0rd@orcl @createDatabaseOracle.ddl  
--
-- ------------------------------------------------------------------------------------


------------------------
-- Create tablespaces --
------------------------
CREATE TABLESPACE BSPACE
  DATAFILE '&1/RMDEFAULTTS32S_BSPACE.dbf' SIZE 500M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING;

-- CREATE TABLESPACE DMSTS  DATAFILE 'RMDEFAULTTS32S_DMSTS.dbf' SIZE 100M AUTOEXTEND ON NEXT 20M MAXSIZE UNLIMITED LOGGING;

-- CREATE TABLESPACE INDEXTS  DATAFILE 'RMDEFAULTTS32S_INDEXTS.dbf' SIZE 250M AUTOEXTEND ON NEXT 50M MAXSIZE UNLIMITED LOGGING;

-- CREATE TABLESPACE LOBTS  DATAFILE 'RMDEFAULTTS32S_LOBTS.dbf' SIZE 200M AUTOEXTEND ON NEXT 40M MAXSIZE UNLIMITED LOGGING;

-------------------------
-- Create schema owner --
-------------------------
CREATE USER IBMBUSSP IDENTIFIED BY wpcdb;

GRANT ALL PRIVILEGES TO IBMBUSSP;

-------------------
-- Create tables --
-------------------

	CREATE TABLE IBMBUSSP.DASHBOARD_DATA_T (
		  DASHBOARD_CONFIG        BLOB NOT NULL ,
		  DASHBOARD_ID            VARCHAR2(128) NOT NULL ,
		  DASHBOARD_OWNER         VARCHAR2(128) NOT NULL ,
		  DASHBOARD_NAME          VARCHAR2(128) NOT NULL ,
		  DASHBOARD_SHARED_USERS  VARCHAR2(512) ,
		  PRIMARY KEY ( DASHBOARD_ID )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.USER_DATA_T (
		  USER_ID                 VARCHAR2(128) NOT NULL ,
		  USER_CONFIG             VARCHAR2(4000) ,
		  IS_SUPER_USER           VARCHAR2(1) ,
		  EXTENSION               BLOB ,
		  PRIMARY KEY ( USER_ID )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.SPACES (
		  ID                      VARCHAR2(64) NOT NULL ,
		  NAME                    VARCHAR2(128) NOT NULL ,
		  DESCRIPTION             VARCHAR2(512) ,
		  OWNER                   VARCHAR2(256) NOT NULL ,
		  USERS                   VARCHAR2(4000) ,
		  EDITORS                 VARCHAR2(4000) ,
		  THEMES                  VARCHAR2(128) ,
		  ISLOCALIZED             VARCHAR2(1) ,
		  TEMPLATE                VARCHAR2(1) NOT NULL ,
		  EXTENSION               BLOB ,
		  PRIMARY KEY ( ID )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.NLSINFO (
		  EXTENSION               BLOB ,
		  ID                      VARCHAR2(64) NOT NULL ,
		  LOCALENAME              VARCHAR2(64) NOT NULL ,
		  DESCRIPTION             VARCHAR2(512) ,
		  NAME                    VARCHAR2(128) NOT NULL ,
		  PRIMARY KEY ( ID, LOCALENAME )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.PAGE (
		  ID                      VARCHAR2(64) NOT NULL ,
		  SPACEID                 VARCHAR2(64) NOT NULL ,
		  NAME                    VARCHAR2(128) NOT NULL ,
		  DESCRIPTION             VARCHAR2(512) ,
		  OWNER                   VARCHAR2(256) NOT NULL ,
		  USERS                   VARCHAR2(4000) ,
		  EDITORS                 VARCHAR2(4000) ,
		  LAYOUT                  VARCHAR2(128) ,
		  WIDGETS                 VARCHAR2(4000) ,
		  ISLOCALIZED             VARCHAR2(1) ,
		  RESTRICTED              VARCHAR2(1) ,
		  TEMPLATE                VARCHAR2(1) NOT NULL ,
		  EXTENSION               BLOB ,
		  PRIMARY KEY ( ID ) ,
		  FOREIGN KEY ( SPACEID )
			REFERENCES IBMBUSSP.SPACES ( ID )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.WIDGET (
		  ID                      VARCHAR2(128) NOT NULL ,
		  NAME                    VARCHAR2(128) ,
		  DEFINITIONID            VARCHAR2(128) NOT NULL ,
		  STATE                   VARCHAR2(32) ,
		  ISLOCALIZED             VARCHAR2(1) ,
		  PREFERENCES             BLOB ,
		  PRIMARY KEY ( ID )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.REGISTERED_WIDGET (
		  EXTENSION               BLOB ,
		  ID_VERSION              VARCHAR2(322) NOT NULL ,
		  ID                      VARCHAR2(256) NOT NULL ,
		  VERSION                 VARCHAR2(64) ,
		  TYPE                    VARCHAR2(32) NOT NULL ,
		  NAME                    VARCHAR2(256) ,
		  DESCRIPTION             VARCHAR2(1024) ,
		  TOOLTIP                 VARCHAR2(512) ,
		  HELP_URL                VARCHAR2(512) ,
		  ICON_URL                VARCHAR2(512) ,
		  PREVIEW_URL             VARCHAR2(512) ,
		  PREVIEW_THUMBNAIL_URL   VARCHAR2(512) ,
		  OWNER                   VARCHAR2(256) ,
		  EMAIL                   VARCHAR2(256) ,
		  SERVICE_ENDPOINTS       VARCHAR2(4000) ,
		  WIDGET_ENDPOINT_ID      VARCHAR2(389) ,
		  WIDGET_URL              VARCHAR2(512) ,
		  VIEW_URL                VARCHAR2(512) ,
		  EDIT_URL                VARCHAR2(512) ,
		  ATTACHABLE              VARCHAR2(8) ,
		  ATTACHMENT_URL          VARCHAR2(512) ,
		  CATEGORY_ID             VARCHAR2(256) NOT NULL ,
		  LAST_CHANGE             TIMESTAMP NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.REGISTERED_WIDGET_NLS (
		  EXTENSION               BLOB ,
		  ID_LOCALE               VARCHAR2(356) NOT NULL ,
		  WIDGET_ID_VERSION       VARCHAR2(322) ,
		  LOCALE                  VARCHAR2(32) ,
		  NAME                    VARCHAR2(256) ,
		  DESCRIPTION             VARCHAR2(1024) ,
		  TOOLTIP                 VARCHAR2(512) ,
		  HELP_URL                VARCHAR2(512) ,
		  ICON_URL                VARCHAR2(512) ,
		  PREVIEW_URL             VARCHAR2(512) ,
		  PREVIEW_THUMBNAIL_URL   VARCHAR2(512) ,
		  OWNER                   VARCHAR2(256) ,
		  EMAIL                   VARCHAR2(256) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( WIDGET_ID_VERSION )
			REFERENCES IBMBUSSP.REGISTERED_WIDGET ( ID_VERSION )
		    ON DELETE CASCADE
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.REGISTERED_CATEGORY (
		  EXTENSION               BLOB ,
		  ID                      VARCHAR2(256) NOT NULL ,
		  ORDERING                NUMBER(3) ,
		  NAME                    VARCHAR2(256) ,
		  DESCRIPTION             VARCHAR2(1024) ,
		  TOOLTIP                 VARCHAR2(512) ,
		  LAST_CHANGE             TIMESTAMP NOT NULL ,
		  PRIMARY KEY ( ID )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.REGISTERED_CATEGORY_NLS (
		  EXTENSION               BLOB ,
		  ID_LOCALE               VARCHAR2(290) NOT NULL ,
		  CATEGORY_ID             VARCHAR2(256) NOT NULL ,
		  LOCALE                  VARCHAR2(32) ,
		  NAME                    VARCHAR2(256) ,
		  DESCRIPTION             VARCHAR2(1024) ,
		  TOOLTIP                 VARCHAR2(512) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( CATEGORY_ID )
			REFERENCES IBMBUSSP.REGISTERED_CATEGORY ( ID )
			ON DELETE CASCADE
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.REGISTERED_ENDPOINT (
		  EXTENSION               BLOB ,
		  ID_VERSION              VARCHAR2(322) NOT NULL ,
		  ID                      VARCHAR2(256) NOT NULL ,
		  VERSION                 VARCHAR2(64) ,
		  URL                     VARCHAR2(512) NOT NULL ,
		  DESCRIPTION             VARCHAR2(1024) ,
		  LAST_CHANGE             TIMESTAMP NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE IBMBUSSP.REGISTRY_FILE (
		  EXTENSION               BLOB ,
		  FILEPATH_HOST           VARCHAR2(770) NOT NULL ,
		  FILEPATH                VARCHAR2(512) NOT NULL ,
		  FILE_TIMESTAMP          NUMBER(38) NOT NULL ,
		  HOST_NAME               VARCHAR2(256) NOT NULL ,
		  PRIMARY KEY ( FILEPATH_HOST )
		) TABLESPACE BSPACE
		LOGGING;
