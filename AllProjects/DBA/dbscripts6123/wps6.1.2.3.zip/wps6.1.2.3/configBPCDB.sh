#!/bin/sh
CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi


. $CURRENT_DIR/../setEnv
cd $CURRENT_DIR/ProcessChoreographer/Oracle/bpcdb 

$ORACLE_HOME/bin/sqlplus -s /nolog << EOF
  CONN bpcdb/bpcdb@$DATABASE
  set echo on
  SPOOL ${LOGDIR}/configBPCDB.lst

  @createTablespace.sql ${BPCDB_TS_ROOT}
  @createSchema.sql

  SPOOL off
EOF
