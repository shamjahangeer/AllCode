--BEGIN CMVC
--*************************************************************************
--
--  Workfile: WBISRVR/ws/code/scheduler.wbi/src/dbscripts/CommonDB/Oracle/createTable_AppScheduler.sql, wbi.scheduler, WBI612.WBISRVR, o0851.02
--  Last update: 07/03/16 03:24:30
--  SCCS path, id: /family/botp/vc/10/9/8/9/s.75 1.2
--
--*************************************************************************
--END CMVC
--BEGIN COPYRIGHT
--*************************************************************************
--
--  Licensed Materials - Property of IBM
--  5724-L01, 5655-N53, 5724-I82, 5655-R15
--  (C) Copyright IBM Corporation 2004, 2006, 2007.
--  All rights reserved. US Government Users Restricted Rights - Use,
--  duplication, or disclosure restricted by GSA ADP Schedule Contract with
--  IBM Corp.
--
--*************************************************************************
--END COPYRIGHT
--
-- create the schema
-- Process this script using SQL*Plus
-- Example:
--  o  sqlplus username/password@WPRCSDB @createTable_AppScheduler.sql
--  o  or, at the sqlplus prompt, enter
--     SQL> @createTable_AppScheduler.sql

CREATE TABLE WSCH_TASK
(
  TASKID             NUMBER(19)            NOT NULL ,
  VERSION            VARCHAR2(5)           NOT NULL ,
  ROW_VERSION        NUMBER(10)            NOT NULL ,
  TASKTYPE           NUMBER(10)            NOT NULL ,
  TASKSUSPENDED      NUMBER(1)             NOT NULL ,
  CANCELLED          NUMBER(1)             NOT NULL ,
  NEXTFIRETIME       NUMBER(19)            NOT NULL ,
  STARTBYINTERVAL    VARCHAR2(254)                  ,
  STARTBYTIME        NUMBER(19)                     ,
  VALIDFROMTIME      NUMBER(19)                     ,
  VALIDTOTIME        NUMBER(19)                     ,
  REPEATINTERVAL     VARCHAR2(254)                  ,
  MAXREPEATS         NUMBER(10)            NOT NULL ,
  REPEATSLEFT        NUMBER(10)            NOT NULL ,
  TASKINFO           BLOB                           ,
  NAME               VARCHAR2(254)                  ,
  AUTOPURGE          NUMBER(10)            NOT NULL ,
  FAILUREACTION      NUMBER(10)                     ,
  MAXATTEMPTS        NUMBER(10)                     ,
  QOS                NUMBER(10)                     ,
  PARTITIONID        NUMBER(10)                     ,
  OWNERTOKEN         VARCHAR2(200)         NOT NULL ,
  CREATETIME         NUMBER(19)            NOT NULL ,
  PRIMARY KEY (TASKID)
) ;

CREATE INDEX WSCH_TASK_IDX1 ON WSCH_TASK
(
  TASKID, OWNERTOKEN
) ;

CREATE INDEX WSCH_TASK_IDX2 ON WSCH_TASK
(
  NEXTFIRETIME ASC ,
  REPEATSLEFT ,
  PARTITIONID
) ;

CREATE TABLE WSCH_TREG
(
  REGKEY             VARCHAR2(254)         NOT NULL ,
  REGVALUE           VARCHAR2(254)                  ,
  PRIMARY KEY ( REGKEY )
) ;

CREATE TABLE WSCH_LMGR
(
  LEASENAME          VARCHAR2(254)         NOT NULL ,
  LEASEOWNER         VARCHAR2(254)                  ,
  LEASE_EXPIRE_TIME  NUMBER(19)                     ,
  DISABLED           VARCHAR2(254)                  ,
  PRIMARY KEY ( LEASENAME )
) ;

CREATE TABLE WSCH_LMPR
(
  LEASENAME          VARCHAR2(254)         NOT NULL ,
  NAME               VARCHAR2(254)         NOT NULL ,
  VALUE              VARCHAR2(254)         NOT NULL
) ;

CREATE INDEX WSCH_LMPR_IDX1 ON WSCH_LMPR
(
  LEASENAME, NAME
) ;

