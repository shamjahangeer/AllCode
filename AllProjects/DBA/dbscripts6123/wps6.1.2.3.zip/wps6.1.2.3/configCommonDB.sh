#!/bin/sh
CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

. $CURRENT_DIR/../setEnv
cd $CURRENT_DIR/CommonDB/Oracle/*

${ORACLE_HOME}/bin/sqlplus -s /nolog << EOF
  CONN wpcdb/wpcdb@${DATABASE}
  set echo on
  SPOOL ${LOGDIR}/configWPCDB.lst

  @createTable_AppScheduler.sql
  @createTable_CommonDB.sql
  @createTable_customization.sql
  @createTable_lockmanager.sql
  @createTable_mediation.sql
  @createTable_Recovery.sql
  @createTable_RelationshipMetadataTable.sql
  @insertTable_CommonDB.sql

  SPOOL off
EOF

${ORACLE_HOME}/bin/sqlplus -s /nolog << EOF
  CONN esblog/esblog@${DATABASE}
  set echo on
  SPOOL ${LOGDIR}/configESBLOG.lst

  @createTable_EsbLoggerMediation.sql

  SPOOL off
EOF
