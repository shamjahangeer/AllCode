#!/bin/sh
CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

. $CURRENT_DIR/../setEnv
cd $CURRENT_DIR/CEI_orcl

${ORACLE_HOME}/bin/sqlplus sys/${SYS_PASSWD}@${DATABASE} as sysdba @cr_ts.ora ${CEIDB_TS_ROOT} 2>&1 > ${LOGDIR}/create_ceidb.lst
${ORACLE_HOME}/bin/sqlplus sys/${SYS_PASSWD}@${DATABASE} as sysdba @cr_ts_catalog.ora ${CEIDB_TS_ROOT} 2>&1 >> ${LOGDIR}/create_ceidb.lst
${ORACLE_HOME}/bin/sqlplus sys/${SYS_PASSWD}@${DATABASE} as sysdba @cr_security.ora 2>&1 >> ${LOGDIR}/create_ceidb.lst

${ORACLE_HOME}/bin/sqlplus -s /nolog 2>&1 >> ${LOGDIR}/create_ceidb.lst << EOF
  CONN sys/${SYS_PASSWD}@${DATABASE} as sysdba 
  set echo on

  CREATE USER CEIDB IDENTIFIED BY ceidb default tablespace ceidb_cei_ts_base temporary tablespace ceidb_cei_ts_temp quota unlimited on ceidb_cei_ts_base
profile ceidb_cei_profile;

  grant ceidb_cei_role, resource, create view to CEIDB;
  alter user CEIDB default role ceidb_cei_role;
  grant execute on dbms_system to
EOF

${ORACLE_HOME}/bin/sqlplus ceidb/ceidb@${DATABASE} @cr_tbl.ora 2>&1 >> ${LOGDIR}/config_ceidb.lst
${ORACLE_HOME}/bin/sqlplus ceidb/ceidb@${DATABASE} @cr_tbl_catalog.ora 2>&1 >> ${LOGDIR}/config_ceidb.lst
${ORACLE_HOME}/bin/sqlplus ceidb/ceidb@${DATABASE} @ins_metadata.ora 2>&1 >> ${LOGDIR}/config_ceidb.lst
${ORACLE_HOME}/bin/sqlplus ceidb/ceidb@${DATABASE} @catalogSeed.ora 2>&1 >> ${LOGDIR}/config_ceidb.lst
${ORACLE_HOME}/bin/sqlplus ceidb/ceidb@${DATABASE} @cr_stored_procedure.ora 2>&1 >> ${LOGDIR}/config_ceidb.lst
