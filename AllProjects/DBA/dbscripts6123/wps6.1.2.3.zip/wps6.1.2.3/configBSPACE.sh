#!/bin/sh
CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

. $CURRENT_DIR/../setEnv
cd $CURRENT_DIR/BusinessSpace/Oracle/*

${ORACLE_HOME}/bin/sqlplus -s /nolog << EOF
  CONN sys/${SYS_PASSWD}@${DATABASE} as sysdba
  set echo on
  SPOOL ${LOGDIR}/configBSPACE.lst

  @createTable_BusinessSpace.sql ${BSPACE_TS_ROOT}

  SPOOL off
EOF
