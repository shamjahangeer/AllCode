--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to create schema for Oracle 9i and Oracle 10g
-- Process this script using SQL*Plus

-------------------
-- Create tables --
-------------------

CREATE TABLE bpcdb.SCHEMA_VERSION
(
  SCHEMA_VERSION                     NUMBER(10,0)         NOT NULL ,
  DATA_MIGRATION                     NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SCHEMA_VERSION ADD(
  PRIMARY KEY ( SCHEMA_VERSION )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.PROCESS_TEMPLATE_B_T
(
  PTID                               RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  DEFINITION_NAME                    VARCHAR2(220)                 ,
  DISPLAY_NAME                       VARCHAR2(64)                  ,
  APPLICATION_NAME                   VARCHAR2(220)                 ,
  DISPLAY_ID                         NUMBER(10,0)         NOT NULL ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  DOCUMENTATION                      CLOB                          ,
  EXECUTION_MODE                     NUMBER(10,0)         NOT NULL ,
  IS_SHARED                          NUMBER(5,0)          NOT NULL ,
  IS_AD_HOC                          NUMBER(5,0)          NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  VALID_FROM                         TIMESTAMP            NOT NULL ,
  TARGET_NAMESPACE                   VARCHAR2(250)                 ,
  CREATED                            TIMESTAMP            NOT NULL ,
  AUTO_DELETE                        NUMBER(5,0)          NOT NULL ,
  EXTENDED_AUTO_DELETE               NUMBER(10,0)         NOT NULL ,
  VERSION                            VARCHAR2(32)                  ,
  SCHEMA_VERSION                     NUMBER(10,0)         NOT NULL ,
  ABSTRACT_BASE_NAME                 VARCHAR2(254)                 ,
  S_BEAN_LOOKUP_NAME                 VARCHAR2(254)                 ,
  S_BEAN60_LOOKUP_NAME               VARCHAR2(254)                 ,
  E_BEAN_LOOKUP_NAME                 VARCHAR2(254)                 ,
  PROCESS_BASE_NAME                  VARCHAR2(254)                 ,
  S_BEAN_HOME_NAME                   VARCHAR2(254)                 ,
  E_BEAN_HOME_NAME                   VARCHAR2(254)                 ,
  BPEWS_UTID                         RAW(16)                       ,
  WPC_UTID                           RAW(16)                       ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  ADMINISTRATOR_QTID                 RAW(16)                       ,
  READER_QTID                        RAW(16)                       ,
  A_TKTID                            RAW(16)                       ,
  A_TKTIDFOR_ACTS                    RAW(16)                       ,
  COMPENSATION_SPHERE                NUMBER(10,0)         NOT NULL ,
  AUTONOMY                           NUMBER(10,0)         NOT NULL ,
  CAN_CALL                           NUMBER(5,0)          NOT NULL ,
  CAN_INITIATE                       NUMBER(5,0)          NOT NULL ,
  CONTINUE_ON_ERROR                  NUMBER(5,0)          NOT NULL ,
  IGNORE_MISSING_DATA                NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROCESS_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.PTB_NAME_VALID ON bpcdb.PROCESS_TEMPLATE_B_T
(   
  NAME, VALID_FROM
) LOGGING;

CREATE INDEX bpcdb.PTB_NAME_VF_STATE ON bpcdb.PROCESS_TEMPLATE_B_T
(   
  NAME, VALID_FROM, STATE, PTID
) LOGGING;

CREATE INDEX bpcdb.PTB_TOP_APP ON bpcdb.PROCESS_TEMPLATE_B_T
(   
  APPLICATION_NAME
) LOGGING;

CREATE INDEX bpcdb.PTB_STATE_PTID ON bpcdb.PROCESS_TEMPLATE_B_T
(   
  STATE, PTID
) LOGGING;

CREATE INDEX bpcdb.PTB_NAME ON bpcdb.PROCESS_TEMPLATE_B_T
(   
  PTID, NAME
) LOGGING;

CREATE TABLE bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T
(
  PTID                               RAW(16)              NOT NULL ,
  ATTR_KEY                           VARCHAR2(220)        NOT NULL ,
  VALUE                              VARCHAR2(254)                 
) LOGGING;

ALTER TABLE bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T ADD(
  PRIMARY KEY ( PTID, ATTR_KEY )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.PTAB_PTID ON bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.SCOPE_TEMPLATE_B_T
(
  STID                               RAW(16)              NOT NULL ,
  PARENT_STID                        RAW(16)                       ,
  PTID                               RAW(16)              NOT NULL ,
  COMP_HANDLER_ATID                  RAW(16)                       ,
  IMPLEMENTS_EHTID                   RAW(16)                       ,
  FOR_EACH_ATID                      RAW(16)                       ,
  DISPLAY_ID                         NUMBER(10,0)         NOT NULL ,
  ISOLATED                           NUMBER(5,0)          NOT NULL ,
  IS_COMPENSABLE                     NUMBER(5,0)          NOT NULL ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  A_TKTID                            RAW(16)                       
) LOGGING;

ALTER TABLE bpcdb.SCOPE_TEMPLATE_B_T ADD(
  PRIMARY KEY ( STID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ST_PTID ON bpcdb.SCOPE_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.SERVICE_TEMPLATE_B_T
(
  VTID                               RAW(16)              NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR2(254)        NOT NULL ,
  PORT_TYPE_UTID                     RAW(16)              NOT NULL ,
  OPERATION_NAME                     VARCHAR2(254)        NOT NULL ,
  NAME                               VARCHAR2(254)                 ,
  PTID                               RAW(16)              NOT NULL ,
  TRANSACTION_BEHAVIOR               NUMBER(10,0)         NOT NULL ,
  IS_TWO_WAY                         NUMBER(5,0)          NOT NULL ,
  NUMBER_OF_RECEIVE_ACTS             NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SERVICE_TEMPLATE_B_T ADD(
  PRIMARY KEY ( VTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.VT_VTID_PTUTID ON bpcdb.SERVICE_TEMPLATE_B_T
(   
  VTID, PORT_TYPE_UTID
) LOGGING;

CREATE INDEX bpcdb.VT_PTID ON bpcdb.SERVICE_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.ACTIVITY_SERVICE_TEMPLATE_B_T
(
  ATID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  PARTNER_LINK_NAME                  VARCHAR2(220)                 ,
  INPUT_CTID                         RAW(16)                       ,
  OUTPUT_CTID                        RAW(16)                       ,
  LINK_ORDER_NUMBER                  NUMBER(10,0)                  ,
  POTENTIAL_OWNER_QTID               RAW(16)                       ,
  READER_QTID                        RAW(16)                       ,
  EDITOR_QTID                        RAW(16)                       ,
  TKTID                              RAW(16)                       ,
  UNDO_MSG_TEMPLATE                  BLOB                          
) LOGGING;

ALTER TABLE bpcdb.ACTIVITY_SERVICE_TEMPLATE_B_T ADD(
  PRIMARY KEY ( ATID, VTID, KIND )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.AST_PTID ON bpcdb.ACTIVITY_SERVICE_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.SERVICE_LOCATION_TEMPLATE_B_T
(
  PTID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)              NOT NULL ,
  MODULE_NAME                        VARCHAR2(220)        NOT NULL ,
  EXPORT_NAME                        CLOB                          ,
  COMPONENT_NAME                     CLOB                 NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SERVICE_LOCATION_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PTID, VTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SLT_PTID ON bpcdb.SERVICE_LOCATION_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.SERVICE_FAULT_TEMPLATE_B_T
(
  VTID                               RAW(16)              NOT NULL ,
  FAULT_NAME                         VARCHAR2(220)        NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  MESSAGE_DEFINITION                 BLOB                 NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SERVICE_FAULT_TEMPLATE_B_T ADD(
  PRIMARY KEY ( VTID, FAULT_NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SFT_PTID ON bpcdb.SERVICE_FAULT_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.ACTIVITY_TEMPLATE_B_T
(
  ATID                               RAW(16)              NOT NULL ,
  PARENT_STID                        RAW(16)                       ,
  IMPLEMENTS_STID                    RAW(16)                       ,
  PTID                               RAW(16)              NOT NULL ,
  IMPLEMENTS_EHTID                   RAW(16)                       ,
  ENCLOSING_FOR_EACH_ATID            RAW(16)                       ,
  IS_EVENT_HANDLER_END_ACTIVITY      NUMBER(5,0)          NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  NAME                               VARCHAR2(220)                 ,
  DISPLAY_NAME                       VARCHAR2(64)                  ,
  JOIN_CONDITION                     NUMBER(10,0)         NOT NULL ,
  JOIN_CONDITION_NAME                VARCHAR2(254)                 ,
  NUMBER_OF_LINKS                    NUMBER(10,0)         NOT NULL ,
  SUPPRESS_JOIN_FAILURE              NUMBER(5,0)          NOT NULL ,
  CREATE_INSTANCE                    NUMBER(5,0)                   ,
  IS_END_ACTIVITY                    NUMBER(5,0)          NOT NULL ,
  FAULT_NAME                         VARCHAR2(254)                 ,
  HAS_OWN_FAULT_HANDLER              NUMBER(5,0)          NOT NULL ,
  COMPLEX_BEGIN_ATID                 RAW(16)                       ,
  CORRESPONDING_END_ATID             RAW(16)                       ,
  PARENT_ATID                        RAW(16)                       ,
  HAS_CROSSING_LINK                  NUMBER(5,0)                   ,
  SCRIPT_NAME                        VARCHAR2(254)                 ,
  AFFILIATION                        NUMBER(10,0)         NOT NULL ,
  TRANSACTION_BEHAVIOR               NUMBER(10,0)         NOT NULL ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  DOCUMENTATION                      CLOB                          ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  FAULT_NAME_UTID                    RAW(16)                       ,
  FAULT_VARIABLE_CTID                RAW(16)                       ,
  DISPLAY_ID                         NUMBER(10,0)         NOT NULL ,
  IS_TRANSACTIONAL                   NUMBER(5,0)          NOT NULL ,
  CONTINUE_ON_ERROR                  NUMBER(5,0)          NOT NULL ,
  ENCLOSED_FTID                      RAW(16)                       ,
  EXPRESSION                         CLOB                          ,
  HAS_INBOUND_LINK                   NUMBER(5,0)          NOT NULL ,
  COMPENSATION_STID                  RAW(16)                       ,
  A_TKTID                            RAW(16)                       ,
  CUSTOM_IMPLEMENTATION              BLOB                          ,
  EXPRESSION_MAP                     BLOB                          
) LOGGING;

ALTER TABLE bpcdb.ACTIVITY_TEMPLATE_B_T ADD(
  PRIMARY KEY ( ATID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ATB_PTID ON bpcdb.ACTIVITY_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE INDEX bpcdb.ATB_NAME ON bpcdb.ACTIVITY_TEMPLATE_B_T
(   
  NAME
) LOGGING;

CREATE INDEX bpcdb.ATB_KIND_BR_NAME ON bpcdb.ACTIVITY_TEMPLATE_B_T
(   
  KIND, BUSINESS_RELEVANCE, NAME
) LOGGING;

CREATE TABLE bpcdb.ALARM_TEMPLATE_B_T
(
  XTID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  EXPRESSION                         BLOB                          ,
  EXPRESSION_NAME                    VARCHAR2(254)                 ,
  DURATION                           VARCHAR2(254)                 ,
  CALENDAR                           VARCHAR2(254)                 ,
  CALENDAR_JNDI_NAME                 VARCHAR2(254)                 ,
  REPEAT_KIND                        NUMBER(10,0)         NOT NULL ,
  REPEAT_EXPRESSION                  BLOB                          ,
  REPEAT_EXP_NAME                    VARCHAR2(254)                 ,
  ON_ALARM_ORDER_NUMBER              NUMBER(10,0)                  ,
  EXPRESSION_MAP                     BLOB                          ,
  REPEAT_EXPRESSION_MAP              BLOB                          
) LOGGING;

ALTER TABLE bpcdb.ALARM_TEMPLATE_B_T ADD(
  PRIMARY KEY ( XTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.XT_PTID ON bpcdb.ALARM_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.FAULT_HANDLER_TEMPLATE_B_T
(
  FTID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  FAULT_NAME                         VARCHAR2(254)                 ,
  CTID                               RAW(16)                       ,
  STID                               RAW(16)                       ,
  ATID                               RAW(16)                       ,
  IMPLEMENTATION_ATID                RAW(16)              NOT NULL ,
  FAULT_NAME_UTID                    RAW(16)                       ,
  ORDER_NUMBER                       NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.FAULT_HANDLER_TEMPLATE_B_T ADD(
  PRIMARY KEY ( FTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.FT_PTID ON bpcdb.FAULT_HANDLER_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.LINK_TEMPLATE_B_T
(
  SOURCE_ATID                        RAW(16)              NOT NULL ,
  TARGET_ATID                        RAW(16)              NOT NULL ,
  FLOW_BEGIN_ATID                    RAW(16)                       ,
  ENCLOSING_FOR_EACH_ATID            RAW(16)                       ,
  DISPLAY_ID                         NUMBER(10,0)         NOT NULL ,
  NAME                               VARCHAR2(254)                 ,
  PTID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  LIFETIME                           NUMBER(10,0)         NOT NULL ,
  TRANSITION_CONDITION               NUMBER(10,0)         NOT NULL ,
  TRANSITION_CONDITION_NAME          VARCHAR2(254)                 ,
  ORDER_NUMBER                       NUMBER(10,0)         NOT NULL ,
  SEQUENCE_NUMBER                    NUMBER(10,0)         NOT NULL ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  DOCUMENTATION                      CLOB                          ,
  EXPRESSION                         CLOB                          ,
  IS_INBOUND_LINK                    NUMBER(5,0)          NOT NULL ,
  OUTBOUND_ATID                      RAW(16)                       ,
  EXPRESSION_MAP                     BLOB                          
) LOGGING;

ALTER TABLE bpcdb.LINK_TEMPLATE_B_T ADD(
  PRIMARY KEY ( SOURCE_ATID, TARGET_ATID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.LNK_PTID ON bpcdb.LINK_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.LINK_BOUNDARY_TEMPLATE_B_T
(
  SOURCE_ATID                        RAW(16)              NOT NULL ,
  TARGET_ATID                        RAW(16)              NOT NULL ,
  BOUNDARY_STID                      RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  IS_OUTMOST_BOUNDARY                NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.LINK_BOUNDARY_TEMPLATE_B_T ADD(
  PRIMARY KEY ( SOURCE_ATID, TARGET_ATID, BOUNDARY_STID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.BND_PTID ON bpcdb.LINK_BOUNDARY_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.RESET_TEMPLATE_B_T
(
  LOOP_ENTRY_ATID                    RAW(16)              NOT NULL ,
  LOOP_BODY_ATID                     RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.RESET_TEMPLATE_B_T ADD(
  PRIMARY KEY ( LOOP_ENTRY_ATID, LOOP_BODY_ATID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.RST_PTID ON bpcdb.RESET_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.VARIABLE_MAPPING_TEMPLATE_B_T
(
  PTID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)              NOT NULL ,
  SOURCE_CTID                        RAW(16)              NOT NULL ,
  TARGET_CTID                        RAW(16)              NOT NULL ,
  PARAMETER                          VARCHAR2(254)        NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.VARIABLE_MAPPING_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PTID, ATID, VTID, SOURCE_CTID, TARGET_CTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.VMT_TCTID ON bpcdb.VARIABLE_MAPPING_TEMPLATE_B_T
(   
  PTID, ATID, VTID, TARGET_CTID
) LOGGING;

CREATE TABLE bpcdb.VARIABLE_TEMPLATE_B_T
(
  CTID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  EHTID                              RAW(16)                       ,
  STID                               RAW(16)                       ,
  FTID                               RAW(16)                       ,
  DERIVED                            NUMBER(5,0)          NOT NULL ,
  DISPLAY_ID                         NUMBER(10,0)         NOT NULL ,
  FROM_SPEC                          NUMBER(10,0)         NOT NULL ,
  NAME                               VARCHAR2(254)        NOT NULL ,
  MESSAGE_TEMPLATE                   BLOB                          ,
  IS_QUERYABLE                       NUMBER(5,0)          NOT NULL ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.VARIABLE_TEMPLATE_B_T ADD(
  PRIMARY KEY ( CTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CT_PTID ON bpcdb.VARIABLE_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.VARIABLE_STACK_TEMPLATE_B_T
(
  VSID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  CTID                               RAW(16)              NOT NULL ,
  STID                               RAW(16)              NOT NULL ,
  FTID                               RAW(16)                       ,
  EHTID                              RAW(16)                       ,
  NAME                               VARCHAR2(255)        NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.VARIABLE_STACK_TEMPLATE_B_T ADD(
  PRIMARY KEY ( VSID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.VS_PTID ON bpcdb.VARIABLE_STACK_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.ACTIVITY_FAULT_TEMPLATE_B_T
(
  AFID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  FAULT_NAME                         VARCHAR2(254)        NOT NULL ,
  FAULT_UTID                         RAW(16)                       ,
  MESSAGE                            BLOB                 NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ACTIVITY_FAULT_TEMPLATE_B_T ADD(
  PRIMARY KEY ( AFID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.AF_PTID ON bpcdb.ACTIVITY_FAULT_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.PARTNER_LINK_TEMPLATE_B_T
(
  PTID                               RAW(16)              NOT NULL ,
  PARTNER_LINK_NAME                  VARCHAR2(220)        NOT NULL ,
  PROCESS_NAME                       VARCHAR2(220)                 ,
  TARGET_NAMESPACE                   VARCHAR2(250)                 ,
  RESOLUTION_SCOPE                   NUMBER(10,0)         NOT NULL ,
  MY_ROLE                            NUMBER(5,0)          NOT NULL ,
  MY_ROLE_IMPL                       BLOB                          ,
  MY_ROLE_LOCALNAME                  VARCHAR2(220)                 ,
  MY_ROLE_NAMESPACE                  VARCHAR2(220)                 ,
  THEIR_ROLE                         NUMBER(5,0)          NOT NULL ,
  THEIR_ROLE_IMPL                    BLOB                          ,
  THEIR_ROLE_LOCALNAME               VARCHAR2(220)                 ,
  THEIR_ROLE_NAMESPACE               VARCHAR2(220)                 
) LOGGING;

ALTER TABLE bpcdb.PARTNER_LINK_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PTID, PARTNER_LINK_NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.URI_TEMPLATE_B_T
(
  UTID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  URI                                VARCHAR2(220)        NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.URI_TEMPLATE_B_T ADD(
  PRIMARY KEY ( UTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.UT_PTID_URI ON bpcdb.URI_TEMPLATE_B_T
(   
  PTID, URI
) LOGGING;

CREATE INDEX bpcdb.UT_UTID_URI ON bpcdb.URI_TEMPLATE_B_T
(   
  UTID, URI
) LOGGING;

CREATE TABLE bpcdb.CLIENT_SETTING_TEMPLATE_B_T
(
  CSID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)                       ,
  PTID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)                       ,
  SETTINGS                           BLOB                          
) LOGGING;

ALTER TABLE bpcdb.CLIENT_SETTING_TEMPLATE_B_T ADD(
  PRIMARY KEY ( CSID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CS_PTID ON bpcdb.CLIENT_SETTING_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.ASSIGN_TEMPLATE_B_T
(
  ATID                               RAW(16)              NOT NULL ,
  ORDER_NUMBER                       NUMBER(10,0)         NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  FROM_SPEC                          NUMBER(10,0)         NOT NULL ,
  FROM_VARIABLE_CTID                 RAW(16)                       ,
  FROM_PARAMETER2                    VARCHAR2(254)                 ,
  FROM_PARAMETER3                    BLOB                          ,
  FROM_PARAMETER3_LANGUAGE           NUMBER(10,0)         NOT NULL ,
  TO_SPEC                            NUMBER(10,0)         NOT NULL ,
  TO_VARIABLE_CTID                   RAW(16)                       ,
  TO_PARAMETER2                      VARCHAR2(254)                 ,
  TO_PARAMETER3                      BLOB                          ,
  TO_PARAMETER3_LANGUAGE             NUMBER(10,0)         NOT NULL ,
  FROM_EXPRESSION_MAP                BLOB                          ,
  TO_EXPRESSION_MAP                  BLOB                          
) LOGGING;

ALTER TABLE bpcdb.ASSIGN_TEMPLATE_B_T ADD(
  PRIMARY KEY ( ATID, ORDER_NUMBER )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ASTB_PTID ON bpcdb.ASSIGN_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.CORRELATION_SET_TEMPLATE_B_T
(
  COID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  STID                               RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(255)        NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CORRELATION_SET_TEMPLATE_B_T ADD(
  PRIMARY KEY ( COID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CSTB_PTID ON bpcdb.CORRELATION_SET_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.CORRELATION_TEMPLATE_B_T
(
  ATID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)              NOT NULL ,
  COID                               RAW(16)              NOT NULL ,
  IS_FOR_EVENT_HANDLER               NUMBER(5,0)          NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  INITIATE                           NUMBER(10,0)         NOT NULL ,
  PATTERN                            NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CORRELATION_TEMPLATE_B_T ADD(
  PRIMARY KEY ( ATID, VTID, COID, IS_FOR_EVENT_HANDLER )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.COID_PTID ON bpcdb.CORRELATION_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T
(
  PAID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  COID                               RAW(16)              NOT NULL ,
  SEQUENCE_NUMBER                    NUMBER(10,0)         NOT NULL ,
  PROPERTY_UTID                      RAW(16)              NOT NULL ,
  PROPERTY_NAME                      VARCHAR2(255)        NOT NULL ,
  JAVA_TYPE                          VARCHAR2(255)        NOT NULL ,
  MSG_TYPE_UTID                      RAW(16)              NOT NULL ,
  MSG_TYPE_NAME                      VARCHAR2(255)        NOT NULL ,
  MSG_TYPE_KIND                      NUMBER(10,0)         NOT NULL ,
  PROPERTY_TYPE_UTID                 RAW(16)                       ,
  PROPERTY_TYPE_NAME                 VARCHAR2(255)                 ,
  PART                               VARCHAR2(255)                 ,
  QUERY                              VARCHAR2(255)                 ,
  QUERY_LANGUAGE                     NUMBER(10,0)         NOT NULL ,
  IS_DEFINED_INLINE                  NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PAID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.PATB_COID_UTID ON bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T
(   
  COID, MSG_TYPE_UTID
) LOGGING;

CREATE INDEX bpcdb.PATB_PTID_UTIDS ON bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T
(   
  PTID, MSG_TYPE_UTID, PROPERTY_UTID
) LOGGING;

CREATE TABLE bpcdb.EVENT_HANDLER_TEMPLATE_B_T
(
  EHTID                              RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  STID                               RAW(16)              NOT NULL ,
  IMPL_ATID                          RAW(16)              NOT NULL ,
  VTID                               RAW(16)                       ,
  INPUT_CTID                         RAW(16)                       ,
  TKTID                              RAW(16)                       ,
  KIND                               NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.EVENT_HANDLER_TEMPLATE_B_T ADD(
  PRIMARY KEY ( EHTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EHT_PTID ON bpcdb.EVENT_HANDLER_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.EHALARM_TEMPLATE_B_T
(
  EHTID                              RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  EXPRESSION                         BLOB                          ,
  EXPRESSION_NAME                    VARCHAR2(254)                 ,
  DURATION                           VARCHAR2(254)                 ,
  CALENDAR                           VARCHAR2(254)                 ,
  CALENDAR_JNDI_NAME                 VARCHAR2(254)                 ,
  REPEAT_KIND                        NUMBER(10,0)         NOT NULL ,
  REPEAT_EXPRESSION                  BLOB                          ,
  REPEAT_EXP_NAME                    VARCHAR2(254)                 ,
  REPEAT_DURATION                    VARCHAR2(254)                 ,
  REPEAT_CALENDAR                    VARCHAR2(254)                 ,
  REPEAT_CALENDAR_JNDI_NAME          VARCHAR2(254)                 ,
  EXPRESSION_MAP                     BLOB                          ,
  REPEAT_EXPRESSION_MAP              BLOB                          
) LOGGING;

ALTER TABLE bpcdb.EHALARM_TEMPLATE_B_T ADD(
  PRIMARY KEY ( EHTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EXT_PTID ON bpcdb.EHALARM_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.CUSTOM_EXT_TEMPLATE_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  NAMESPACE                          VARCHAR2(220)        NOT NULL ,
  LOCALNAME                          VARCHAR2(220)        NOT NULL ,
  TEMPLATE_INFO                      BLOB                          ,
  INSTANCE_INFO                      BLOB                          
) LOGGING;

ALTER TABLE bpcdb.CUSTOM_EXT_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CETB_PTID ON bpcdb.CUSTOM_EXT_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.CUSTOM_STMT_TEMPLATE_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  NAMESPACE                          VARCHAR2(220)        NOT NULL ,
  LOCALNAME                          VARCHAR2(220)        NOT NULL ,
  PURPOSE                            VARCHAR2(220)        NOT NULL ,
  STATEMENT                          BLOB                          
) LOGGING;

ALTER TABLE bpcdb.CUSTOM_STMT_TEMPLATE_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CST_PTID_NS_LN_P ON bpcdb.CUSTOM_STMT_TEMPLATE_B_T
(   
  PTID, NAMESPACE, LOCALNAME, PURPOSE
) LOGGING;

CREATE TABLE bpcdb.PROCESS_CELL_MAP_T
(
  PTID                               RAW(16)              NOT NULL ,
  CELL                               VARCHAR2(220)        NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROCESS_CELL_MAP_T ADD(
  PRIMARY KEY ( PTID, CELL )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.ACTIVITY_TEMPLATE_ATTR_B_T
(
  ATID                               RAW(16)              NOT NULL ,
  ATTR_KEY                           VARCHAR2(192)        NOT NULL ,
  ATTR_VALUE                         VARCHAR2(254)                 ,
  PTID                               RAW(16)              NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ACTIVITY_TEMPLATE_ATTR_B_T ADD(
  PRIMARY KEY ( ATID, ATTR_KEY )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ATAB_PTID ON bpcdb.ACTIVITY_TEMPLATE_ATTR_B_T
(   
  PTID
) LOGGING;

CREATE INDEX bpcdb.ATAB_VALUE ON bpcdb.ACTIVITY_TEMPLATE_ATTR_B_T
(   
  ATTR_VALUE
) LOGGING;

CREATE TABLE bpcdb.FOR_EACH_TEMPLATE_B_T
(
  ATID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  COUNTER_CTID                       RAW(16)              NOT NULL ,
  SUCCESSFUL_BRANCHES_ONLY           NUMBER(5,0)          NOT NULL ,
  START_COUNTER_LANGUAGE             NUMBER(10,0)         NOT NULL ,
  FINAL_COUNTER_LANGUAGE             NUMBER(10,0)         NOT NULL ,
  COMPLETION_CONDITION_LANGUAGE      NUMBER(10,0)         NOT NULL ,
  START_COUNTER_EXPRESSION           BLOB                          ,
  FINAL_COUNTER_EXPRESSION           BLOB                          ,
  COMPLETION_COND_EXPRESSION         BLOB                          ,
  FOR_EACH_METHOD                    VARCHAR2(254)                 ,
  START_COUNTER_EXPRESSION_MAP       BLOB                          ,
  FINAL_COUNTER_EXPRESSION_MAP       BLOB                          ,
  COMPLETION_COND_EXPRESSION_MAP     BLOB                          
) LOGGING;

ALTER TABLE bpcdb.FOR_EACH_TEMPLATE_B_T ADD(
  PRIMARY KEY ( ATID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.FET_PTID ON bpcdb.FOR_EACH_TEMPLATE_B_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.GRAPHICAL_PROCESS_MODEL_T
(
  PTID                               RAW(16)              NOT NULL ,
  SOURCE                             VARCHAR2(100)        NOT NULL ,
  KIND                               VARCHAR2(100)        NOT NULL ,
  GRAPHICAL_DATA                     BLOB                          ,
  ID_MAPPING                         BLOB                          
) LOGGING;

ALTER TABLE bpcdb.GRAPHICAL_PROCESS_MODEL_T ADD(
  PRIMARY KEY ( PTID, SOURCE, KIND )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T
(
  PKID                               RAW(16)              NOT NULL ,
  CTID                               RAW(16)              NOT NULL ,
  PAID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  QUERY_TYPE                         NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.QVT_PTID ON bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T
(   
  PTID
) LOGGING;

CREATE TABLE bpcdb.STAFF_QUERY_TEMPLATE_T
(
  QTID                               RAW(16)              NOT NULL ,
  ASSOCIATED_OBJECT_TYPE             NUMBER(10,0)         NOT NULL ,
  ASSOCIATED_OID                     RAW(16)              NOT NULL ,
  T_QUERY                            VARCHAR2(32)         NOT NULL ,
  QUERY                              BLOB                 NOT NULL ,
  HASH_CODE                          NUMBER(10,0)         NOT NULL ,
  SUBSTITUTION_POLICY                NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.STAFF_QUERY_TEMPLATE_T ADD(
  PRIMARY KEY ( QTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SQT_HASH ON bpcdb.STAFF_QUERY_TEMPLATE_T
(   
  ASSOCIATED_OID, HASH_CODE, T_QUERY, ASSOCIATED_OBJECT_TYPE
) LOGGING;

CREATE TABLE bpcdb.PROCESS_INSTANCE_B_T
(
  PIID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  PENDING_REQUEST                    NUMBER(10,0)         NOT NULL ,
  CREATED                            TIMESTAMP                     ,
  STARTED                            TIMESTAMP                     ,
  COMPLETED                          TIMESTAMP                     ,
  LAST_STATE_CHANGE                  TIMESTAMP                     ,
  LAST_MODIFIED                      TIMESTAMP                     ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  PARENT_NAME                        VARCHAR2(220)                 ,
  TOP_LEVEL_NAME                     VARCHAR2(220)        NOT NULL ,
  COMPENSATION_SPHERE_NAME           VARCHAR2(100)                 ,
  STARTER                            VARCHAR2(128)                 ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  INPUT_SNID                         RAW(16)                       ,
  INPUT_ATID                         RAW(16)                       ,
  INPUT_VTID                         RAW(16)                       ,
  OUTPUT_SNID                        RAW(16)                       ,
  OUTPUT_ATID                        RAW(16)                       ,
  OUTPUT_VTID                        RAW(16)                       ,
  FAULT_NAME                         VARCHAR2(254)                 ,
  TOP_LEVEL_PIID                     RAW(16)              NOT NULL ,
  PARENT_PIID                        RAW(16)                       ,
  PARENT_AIID                        RAW(16)                       ,
  TKIID                              RAW(16)                       ,
  TERMIN_ON_REC                      NUMBER(5,0)          NOT NULL ,
  AWAITED_SUB_PROC                   NUMBER(5,0)          NOT NULL ,
  IS_CREATING                        NUMBER(5,0)          NOT NULL ,
  PREVIOUS_STATE                     NUMBER(10,0)                  ,
  EXECUTING_ISOLATED_SCOPE           NUMBER(5,0)          NOT NULL ,
  SCHEDULER_TASK_ID                  VARCHAR2(254)                 ,
  RESUMES                            TIMESTAMP                     ,
  PENDING_SKIP_REQUEST               NUMBER(5,0)          NOT NULL ,
  UNHANDLED_EXCEPTION                BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROCESS_INSTANCE_B_T ADD(
  PRIMARY KEY ( PIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.PIB_NAME ON bpcdb.PROCESS_INSTANCE_B_T
(   
  NAME
) LOGGING;

CREATE INDEX bpcdb.PIB_TOP ON bpcdb.PROCESS_INSTANCE_B_T
(   
  TOP_LEVEL_PIID
) LOGGING;

CREATE INDEX bpcdb.PIB_PAP ON bpcdb.PROCESS_INSTANCE_B_T
(   
  PARENT_PIID
) LOGGING;

CREATE INDEX bpcdb.PIB_PAR ON bpcdb.PROCESS_INSTANCE_B_T
(   
  PARENT_AIID
) LOGGING;

CREATE INDEX bpcdb.PIB_PTID ON bpcdb.PROCESS_INSTANCE_B_T
(   
  PTID
) LOGGING;

CREATE INDEX bpcdb.PIB_PIID_STATE ON bpcdb.PROCESS_INSTANCE_B_T
(   
  PIID, STATE
) LOGGING;

CREATE INDEX bpcdb.PIB_STATE ON bpcdb.PROCESS_INSTANCE_B_T
(   
  STATE
) LOGGING;

CREATE INDEX bpcdb.PIB_PIID_PTID_STAT ON bpcdb.PROCESS_INSTANCE_B_T
(   
  PIID, PTID, STATE, STARTER, STARTED
) LOGGING;

CREATE TABLE bpcdb.SCOPE_INSTANCE_B_T
(
  SIID                               RAW(16)              NOT NULL ,
  PARENT_SIID                        RAW(16)                       ,
  STID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  ENCLOSING_FEIID                    RAW(16)                       ,
  ENCLOSING_FOR_EACH_END_AIID        RAW(16)                       ,
  COMPENSATE_AIID                    RAW(16)                       ,
  PARENT_COMP_SIID                   RAW(16)                       ,
  LAST_COMP_SIID                     RAW(16)                       ,
  RUNNING_EVENT_HANDLERS             NUMBER(10,0)         NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  NOTIFY_PARENT                      NUMBER(5,0)          NOT NULL ,
  AWAITED_SCOPES                     NUMBER(10,0)         NOT NULL ,
  AWAITED_SUB_PROCESSES              NUMBER(10,0)         NOT NULL ,
  BPEL_EXCEPTION                     BLOB                          ,
  IS_ACTIVE                          NUMBER(5,0)          NOT NULL ,
  INITIATED_COMP                     NUMBER(5,0)          NOT NULL ,
  IS_TERMINATION_FROM_FOR_EACH       NUMBER(5,0)          NOT NULL ,
  TOTAL_COMPL_NUMBER                 NUMBER(20,0)         NOT NULL ,
  SCOPE_COMPL_NUMBER                 NUMBER(20,0)         NOT NULL ,
  A_TKIID                            RAW(16)                       ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SCOPE_INSTANCE_B_T ADD(
  PRIMARY KEY ( SIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SI_PI_ST_EH_STA_FE ON bpcdb.SCOPE_INSTANCE_B_T
(   
  PIID, STID, STATE, EHIID, ENCLOSING_FEIID
) LOGGING;

CREATE INDEX bpcdb.SI_PI_ST_EH_ACT_FE ON bpcdb.SCOPE_INSTANCE_B_T
(   
  PIID, STID, IS_ACTIVE, EHIID, ENCLOSING_FEIID
) LOGGING;

CREATE INDEX bpcdb.SI_PIID_PARSI ON bpcdb.SCOPE_INSTANCE_B_T
(   
  PIID, PARENT_SIID, IS_ACTIVE
) LOGGING;

CREATE INDEX bpcdb.SI_PARCOMP_STA_ST ON bpcdb.SCOPE_INSTANCE_B_T
(   
  PARENT_COMP_SIID, STATE, STID
) LOGGING;

CREATE INDEX bpcdb.SI_PIID_STATE ON bpcdb.SCOPE_INSTANCE_B_T
(   
  PIID, STATE
) LOGGING;

CREATE INDEX bpcdb.SI_LAST_COMPSIID ON bpcdb.SCOPE_INSTANCE_B_T
(   
  LAST_COMP_SIID
) LOGGING;

CREATE TABLE bpcdb.ACTIVITY_INSTANCE_B_T
(
  AIID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  SIID                               RAW(16)                       ,
  PIID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  ENCLOSING_FEIID                    RAW(16)                       ,
  P_TKIID                            RAW(16)                       ,
  A_TKIID                            RAW(16)                       ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  TRANS_COND_VALUES                  RAW(66)              NOT NULL ,
  NUMBER_LINKS_EVALUATED             NUMBER(10,0)         NOT NULL ,
  FINISHED                           TIMESTAMP                     ,
  ACTIVATED                          TIMESTAMP                     ,
  FIRST_ACTIVATED                    TIMESTAMP                     ,
  STARTED                            TIMESTAMP                     ,
  LAST_MODIFIED                      TIMESTAMP                     ,
  LAST_STATE_CHANGE                  TIMESTAMP                     ,
  OWNER                              VARCHAR2(128)                 ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  LINK_ORDER_NUMBER                  NUMBER(10,0)                  ,
  SCHEDULER_TASK_ID                  VARCHAR2(254)                 ,
  EXPIRES                            TIMESTAMP                     ,
  CONTINUE_ON_ERROR                  NUMBER(5,0)          NOT NULL ,
  UNHANDLED_EXCEPTION                BLOB                          ,
  STOP_REASON                        NUMBER(10,0)         NOT NULL ,
  INVOCATION_COUNTER                 NUMBER(10,0)         NOT NULL ,
  FOR_EACH_START_COUNTER_VALUE       NUMBER(20,0)                  ,
  FOR_EACH_FINAL_COUNTER_VALUE       NUMBER(20,0)                  ,
  FOR_EACH_CURRENT_COUNTER_VALUE     NUMBER(20,0)                  ,
  FOR_EACH_COMPLETED_BRANCHES        NUMBER(20,0)                  ,
  FOR_EACH_FAILED_BRANCHES           NUMBER(20,0)                  ,
  FOR_EACH_MAX_COMPL_BRANCHES        NUMBER(20,0)                  ,
  FOR_EACH_AWAITED_BRANCHES          NUMBER(20,0)                  ,
  IS51_ACTIVITY                      NUMBER(5,0)          NOT NULL ,
  MAY_HAVE_SUBPROCESS                NUMBER(5,0)                   ,
  SKIP_REQUESTED                     NUMBER(5,0)          NOT NULL ,
  JUMP_TARGET_ATID                   RAW(16)                       ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ACTIVITY_INSTANCE_B_T ADD(
  PRIMARY KEY ( AIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.AIB_PI_ATID_EH_FE ON bpcdb.ACTIVITY_INSTANCE_B_T
(   
  PIID, ATID, EHIID, ENCLOSING_FEIID
) LOGGING;

CREATE INDEX bpcdb.AIB_PTID ON bpcdb.ACTIVITY_INSTANCE_B_T
(   
  PTID
) LOGGING;

CREATE INDEX bpcdb.AIB_PIID_STAT_AIID ON bpcdb.ACTIVITY_INSTANCE_B_T
(   
  PIID, STATE, AIID, ACTIVATED
) LOGGING;

CREATE INDEX bpcdb.AIB_AI_AT_STAT_PI ON bpcdb.ACTIVITY_INSTANCE_B_T
(   
  AIID, ATID, STATE, PIID, OWNER, ACTIVATED
) LOGGING;

CREATE INDEX bpcdb.AIB_SIID ON bpcdb.ACTIVITY_INSTANCE_B_T
(   
  SIID
) LOGGING;

CREATE TABLE bpcdb.VARIABLE_INSTANCE_B_T
(
  CTID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  DATA                               BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.VARIABLE_INSTANCE_B_T ADD(
  PRIMARY KEY ( CTID, PIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CI_PIID ON bpcdb.VARIABLE_INSTANCE_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.SCOPED_VARIABLE_INSTANCE_B_T
(
  SVIID                              RAW(16)              NOT NULL ,
  CTID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  SIID                               RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  FEIID                              RAW(16)                       ,
  DATA                               BLOB                          ,
  IS_ACTIVE                          NUMBER(5,0)          NOT NULL ,
  IS_INITIALIZED                     NUMBER(5,0)          NOT NULL ,
  IS_QUERYABLE                       NUMBER(5,0)          NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SCOPED_VARIABLE_INSTANCE_B_T ADD(
  PRIMARY KEY ( SVIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SVI_PI_CT_EH_FE ON bpcdb.SCOPED_VARIABLE_INSTANCE_B_T
(   
  PIID, CTID, IS_ACTIVE, EHIID, FEIID
) LOGGING;

CREATE INDEX bpcdb.SVI_CT_SI_EH_AC ON bpcdb.SCOPED_VARIABLE_INSTANCE_B_T
(   
  SIID, CTID, IS_ACTIVE, EHIID
) LOGGING;

CREATE TABLE bpcdb.STAFF_MESSAGE_INSTANCE_B_T
(
  AIID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  DATA                               BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.STAFF_MESSAGE_INSTANCE_B_T ADD(
  PRIMARY KEY ( AIID, KIND )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SMI_PIID ON bpcdb.STAFF_MESSAGE_INSTANCE_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.EVENT_INSTANCE_B_T
(
  EIID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)              NOT NULL ,
  IS_TWO_WAY                         NUMBER(5,0)          NOT NULL ,
  IS_PRIMARY_EVENT_INSTANCE          NUMBER(5,0)          NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  AIID                               RAW(16)                       ,
  EHTID                              RAW(16)                       ,
  SIID                               RAW(16)                       ,
  TKIID                              RAW(16)                       ,
  NEXT_POSTED_EVENT                  RAW(16)                       ,
  LAST_POSTED_EVENT                  RAW(16)                       ,
  POST_COUNT                         NUMBER(10,0)         NOT NULL ,
  MESSAGE                            BLOB                          ,
  REPLY_CONTEXT                      BLOB                          ,
  POST_TIME                          TIMESTAMP                     ,
  MAX_NUMBER_OF_POSTS                NUMBER(10,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.EVENT_INSTANCE_B_T ADD(
  PRIMARY KEY ( EIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EI_PIID_PRIM ON bpcdb.EVENT_INSTANCE_B_T
(   
  PIID, IS_PRIMARY_EVENT_INSTANCE, STATE
) LOGGING;

CREATE INDEX bpcdb.EI_PIID_VTID ON bpcdb.EVENT_INSTANCE_B_T
(   
  PIID, VTID, IS_PRIMARY_EVENT_INSTANCE
) LOGGING;

CREATE INDEX bpcdb.EI_AIID ON bpcdb.EVENT_INSTANCE_B_T
(   
  AIID
) LOGGING;

CREATE INDEX bpcdb.EI_STATE_VTID ON bpcdb.EVENT_INSTANCE_B_T
(   
  VTID, STATE, EIID, AIID, PIID
) LOGGING;

CREATE TABLE bpcdb.REQUEST_INSTANCE_B_T
(
  RIID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  VTID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  TKIID                              RAW(16)                       ,
  FEIID                              RAW(16)                       ,
  INSTANTIATING                      NUMBER(5,0)          NOT NULL ,
  REPLY_CONTEXT                      BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.REQUEST_INSTANCE_B_T ADD(
  PRIMARY KEY ( RIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.RI_PIID_VTID_EHIID ON bpcdb.REQUEST_INSTANCE_B_T
(   
  PIID, VTID
) LOGGING;

CREATE TABLE bpcdb.PARTNER_LINK_INSTANCE_B_T
(
  PIID                               RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  ENDPOINT_REFERENCE                 BLOB                          ,
  SERVICE_DEFINITION                 BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PARTNER_LINK_INSTANCE_B_T ADD(
  PRIMARY KEY ( PIID, NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.PA_PIID ON bpcdb.PARTNER_LINK_INSTANCE_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.VARIABLE_SNAPSHOT_B_T
(
  SNID                               RAW(16)              NOT NULL ,
  CTID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  DATA                               BLOB                          ,
  COPY_VERSION                       NUMBER(5,0)          NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.VARIABLE_SNAPSHOT_B_T ADD(
  PRIMARY KEY ( SNID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SN_PIID_CTID ON bpcdb.VARIABLE_SNAPSHOT_B_T
(   
  PIID, CTID
) LOGGING;

CREATE TABLE bpcdb.CORR_SET_B_T
(
  PTID                               RAW(16)              NOT NULL ,
  CORR_SET                           VARCHAR2(230)        NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CORR_SET_B_T ADD(
  PRIMARY KEY ( PTID, CORR_SET )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.COS_PIID ON bpcdb.CORR_SET_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.SUSPENDED_MESSAGE_INSTANCE_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  ENGINE_MESSAGE                     BLOB                 NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SUSPENDED_MESSAGE_INSTANCE_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.PIID ON bpcdb.SUSPENDED_MESSAGE_INSTANCE_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.CROSSING_LINK_INSTANCE_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  SOURCE_ATID                        RAW(16)              NOT NULL ,
  TARGET_ATID                        RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  FEIID                              RAW(16)                       ,
  CONDITION_VALUE                    NUMBER(10,0)         NOT NULL ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CROSSING_LINK_INSTANCE_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CL_PI_TAT_EH_FE_SA ON bpcdb.CROSSING_LINK_INSTANCE_B_T
(   
  PIID, TARGET_ATID, EHIID, FEIID, SOURCE_ATID
) LOGGING;

CREATE TABLE bpcdb.INVOKE_RESULT_B_T
(
  PIID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  INVOKE_RESULT                      BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.INVOKE_RESULT_B_T ADD(
  PRIMARY KEY ( PIID, ATID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.INVOKE_RESULT2_B_T
(
  IRID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  FEIID                              RAW(16)                       ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  INVOKE_RESULT                      BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.INVOKE_RESULT2_B_T ADD(
  PRIMARY KEY ( IRID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.IR2_PI_AT_EH_FE ON bpcdb.INVOKE_RESULT2_B_T
(   
  PIID, ATID, EHIID, FEIID
) LOGGING;

CREATE TABLE bpcdb.EVENT_HANDLER_INSTANCE_B_T
(
  EHIID                              RAW(16)              NOT NULL ,
  EHTID                              RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  SIID                               RAW(16)              NOT NULL ,
  PARENT_EHIID                       RAW(16)                       ,
  FEIID                              RAW(16)                       ,
  SCHEDULER_TASK_ID                  VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.EVENT_HANDLER_INSTANCE_B_T ADD(
  PRIMARY KEY ( EHIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EHI_PIID_EHTID ON bpcdb.EVENT_HANDLER_INSTANCE_B_T
(   
  PIID, EHTID
) LOGGING;

CREATE INDEX bpcdb.EHI_SIID_EHTID ON bpcdb.EVENT_HANDLER_INSTANCE_B_T
(   
  SIID, EHTID
) LOGGING;

CREATE TABLE bpcdb.CORRELATION_SET_INSTANCE_B_T
(
  PIID                               RAW(16)              NOT NULL ,
  COID                               RAW(16)              NOT NULL ,
  SIID                               RAW(16)              NOT NULL ,
  PROCESS_NAME                       VARCHAR2(220)        NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  STATUS                             NUMBER(10,0)         NOT NULL ,
  HASH_CODE                          RAW(16)              NOT NULL ,
  DATA                               VARCHAR2(3072)                ,
  DATA_LONG                          CLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CORRELATION_SET_INSTANCE_B_T ADD(
  PRIMARY KEY ( PIID, COID, SIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.CSIB_HASH_PN ON bpcdb.CORRELATION_SET_INSTANCE_B_T
(   
  HASH_CODE, PROCESS_NAME
) LOGGING;

CREATE INDEX bpcdb.CSIB_PIID ON bpcdb.CORRELATION_SET_INSTANCE_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.CORRELATION_SET_PROPERTIES_B_T
(
  PIID                               RAW(16)              NOT NULL ,
  COID                               RAW(16)              NOT NULL ,
  SIID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  DATA                               BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CORRELATION_SET_PROPERTIES_B_T ADD(
  PRIMARY KEY ( PIID, COID, SIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.UNDO_ACTION_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  PARENT_ATID                        RAW(16)                       ,
  PARENT_PIID                        RAW(16)                       ,
  PARENT_AIID                        RAW(16)                       ,
  PARENT_EHIID                       RAW(16)                       ,
  PARENT_FEIID                       RAW(16)                       ,
  PROCESS_NAME                       VARCHAR2(220)        NOT NULL ,
  CSCOPE_ID                          VARCHAR2(100)        NOT NULL ,
  UUID                               VARCHAR2(100)        NOT NULL ,
  COMP_CREATION_TIME                 TIMESTAMP            NOT NULL ,
  DO_OP_WAS_TXNAL                    NUMBER(5,0)          NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  INPUT_DATA                         BLOB                 NOT NULL ,
  FAULT_DATA                         BLOB                          ,
  CREATED                            NUMBER(10,0)         NOT NULL ,
  PROCESS_ADMIN                      VARCHAR2(128)        NOT NULL ,
  IS_VISIBLE                         NUMBER(5,0)          NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.UNDO_ACTION_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.UA_CSID_DOOP_UUID ON bpcdb.UNDO_ACTION_B_T
(   
  CSCOPE_ID, DO_OP_WAS_TXNAL, UUID
) LOGGING;

CREATE INDEX bpcdb.UA_CSID_STATE_CCT ON bpcdb.UNDO_ACTION_B_T
(   
  CSCOPE_ID, STATE, UUID
) LOGGING;

CREATE INDEX bpcdb.UA_STATE_ISV ON bpcdb.UNDO_ACTION_B_T
(   
  STATE, IS_VISIBLE
) LOGGING;

CREATE INDEX bpcdb.UA_AIID_STATE_UUID ON bpcdb.UNDO_ACTION_B_T
(   
  PARENT_AIID, STATE, UUID
) LOGGING;

CREATE INDEX bpcdb.UA_PIID ON bpcdb.UNDO_ACTION_B_T
(   
  PARENT_PIID
) LOGGING;

CREATE INDEX bpcdb.UA_PT_AT_CS_UU_CCT ON bpcdb.UNDO_ACTION_B_T
(   
  PTID, ATID, CSCOPE_ID, UUID, COMP_CREATION_TIME
) LOGGING;

CREATE TABLE bpcdb.CUSTOM_STMT_INSTANCE_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  SVIID                              RAW(16)                       ,
  NAMESPACE                          VARCHAR2(220)        NOT NULL ,
  LOCALNAME                          VARCHAR2(220)        NOT NULL ,
  PURPOSE                            VARCHAR2(220)        NOT NULL ,
  STATEMENT                          BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CUSTOM_STMT_INSTANCE_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CSI_PIID_NS_LN_P ON bpcdb.CUSTOM_STMT_INSTANCE_B_T
(   
  PIID, NAMESPACE, LOCALNAME, PURPOSE
) LOGGING;

CREATE INDEX bpcdb.CSI_SVIID_NS_LN_P ON bpcdb.CUSTOM_STMT_INSTANCE_B_T
(   
  SVIID, NAMESPACE, LOCALNAME, PURPOSE
) LOGGING;

CREATE TABLE bpcdb.COMP_WORK_PENDING_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PARENT_PIID                        RAW(16)              NOT NULL ,
  PARENT_ATID                        RAW(16)              NOT NULL ,
  PARENT_EHIID                       RAW(16)                       ,
  PARENT_FEIID                       RAW(16)                       ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  CSCOPE_ID                          VARCHAR2(100)        NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.COMP_WORK_PENDING_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CWP_PI_AT_CS_EH_FE ON bpcdb.COMP_WORK_PENDING_B_T
(   
  PARENT_PIID, PARENT_ATID, CSCOPE_ID, PARENT_EHIID, PARENT_FEIID
) LOGGING;

CREATE INDEX bpcdb.CWP_PI_AT_EHI ON bpcdb.COMP_WORK_PENDING_B_T
(   
  PARENT_PIID, PARENT_ATID, PARENT_EHIID
) LOGGING;

CREATE TABLE bpcdb.COMP_PARENT_ACTIVITY_INST_B_T
(
  AIID                               RAW(16)              NOT NULL ,
  SIID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  COMPLETION_NUMBER                  NUMBER(20,0)         NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.COMP_PARENT_ACTIVITY_INST_B_T ADD(
  PRIMARY KEY ( AIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CPAI_SI_S_CN_AI_PI ON bpcdb.COMP_PARENT_ACTIVITY_INST_B_T
(   
  SIID, STATE, COMPLETION_NUMBER, AIID, PIID
) LOGGING;

CREATE INDEX bpcdb.CPAI_PIID ON bpcdb.COMP_PARENT_ACTIVITY_INST_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.RESTART_EVENT_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  PORT_TYPE                          VARCHAR2(254)        NOT NULL ,
  OPERATION                          VARCHAR2(254)        NOT NULL ,
  NAMESPACE                          VARCHAR2(254)        NOT NULL ,
  INPUT_MESSAGE                      BLOB                          ,
  REPLY_CTX                          BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.RESTART_EVENT_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.REB_PIID ON bpcdb.RESTART_EVENT_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.PROGRESS_COUNTER_T
(
  PIID                               RAW(16)              NOT NULL ,
  COUNTER                            NUMBER(20,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROGRESS_COUNTER_T ADD(
  PRIMARY KEY ( PIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.RELEVANT_SCOPE_ATASK_T
(
  SIID                               RAW(16)              NOT NULL ,
  TKIID                              RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.RELEVANT_SCOPE_ATASK_T ADD(
  PRIMARY KEY ( SIID, TKIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.CONFIG_INFO_T
(
  IDENTIFIER                         VARCHAR2(64)         NOT NULL ,
  DESCRIPTION                        VARCHAR2(128)                 ,
  PROPERTY                           NUMBER(10,0)                  ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CONFIG_INFO_T ADD(
  PRIMARY KEY ( IDENTIFIER )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T
(
  PIID                               RAW(16)              NOT NULL ,
  ATTR_KEY                           VARCHAR2(220)        NOT NULL ,
  VALUE                              VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T ADD(
  PRIMARY KEY ( PIID, ATTR_KEY )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.PIA_VALUE ON bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T
(   
  VALUE
) LOGGING;

CREATE TABLE bpcdb.PROCESS_CONTEXT_T
(
  PIID                               RAW(16)              NOT NULL ,
  REPLY_CONTEXT                      BLOB                          ,
  SERVICE_CONTEXT                    BLOB                          ,
  STARTER_EXPIRES                    TIMESTAMP                     ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.PROCESS_CONTEXT_T ADD(
  PRIMARY KEY ( PIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.ACTIVITY_INSTANCE_ATTR_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  ATID                               RAW(16)              NOT NULL ,
  EHIID                              RAW(16)                       ,
  FEIID                              RAW(16)                       ,
  AIID                               RAW(16)                       ,
  ATTR_KEY                           VARCHAR2(189)        NOT NULL ,
  ATTR_VALUE                         VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ACTIVITY_INSTANCE_ATTR_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.AIA_UNIQUE ON bpcdb.ACTIVITY_INSTANCE_ATTR_B_T
(   
  PIID, ATID, EHIID, FEIID, ATTR_KEY
) LOGGING;

CREATE INDEX bpcdb.AIA_AIID ON bpcdb.ACTIVITY_INSTANCE_ATTR_B_T
(   
  AIID
) LOGGING;

CREATE INDEX bpcdb.AIA_VALUE ON bpcdb.ACTIVITY_INSTANCE_ATTR_B_T
(   
  ATTR_VALUE
) LOGGING;

CREATE TABLE bpcdb.NAVIGATION_EXCEPTION_T
(
  CORRELATION_ID                     RAW(220)             NOT NULL ,
  EXCEPTION_TYPE                     NUMBER(10,0)         NOT NULL ,
  OUTPUT_MESSAGE                     BLOB                          ,
  TYPE_SYSTEM                        VARCHAR2(32)                  ,
  PROCESS_EXCEPTION                  BLOB                 NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.NAVIGATION_EXCEPTION_T ADD(
  PRIMARY KEY ( CORRELATION_ID, EXCEPTION_TYPE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.AWAITED_INVOCATION_T
(
  CORRELATION_ID                     RAW(254)             NOT NULL ,
  CORRELATION_INFO                   BLOB                 NOT NULL ,
  AIID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.AWAITED_INVOCATION_T ADD(
  PRIMARY KEY ( CORRELATION_ID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.AWI_PIID ON bpcdb.AWAITED_INVOCATION_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.STORED_QUERY_T
(
  SQID                               RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  NAME                               VARCHAR2(64)         NOT NULL ,
  OWNER_ID                           VARCHAR2(128)        NOT NULL ,
  SELECT_CLAUSE                      CLOB                 NOT NULL ,
  WHERE_CLAUSE                       CLOB                          ,
  ORDER_CLAUSE                       VARCHAR2(254)                 ,
  THRESHOLD                          NUMBER(10,0)                  ,
  TIMEZONE                           VARCHAR2(63)                  ,
  CREATOR                            VARCHAR2(128)                 ,
  TYPE                               VARCHAR2(128)                 ,
  PROPERTY                           BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.STORED_QUERY_T ADD(
  PRIMARY KEY ( SQID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.SQ_NAME ON bpcdb.STORED_QUERY_T
(   
  KIND, OWNER_ID, NAME
) LOGGING;

CREATE TABLE bpcdb.FOR_EACH_INSTANCE_B_T
(
  FEIID                              RAW(16)              NOT NULL ,
  PARENT_FEIID                       RAW(16)                       ,
  PIID                               RAW(16)              NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.FOR_EACH_INSTANCE_B_T ADD(
  PRIMARY KEY ( FEIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.FEI_PIID ON bpcdb.FOR_EACH_INSTANCE_B_T
(   
  PIID
) LOGGING;

CREATE TABLE bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(
  PKID                               RAW(16)              NOT NULL ,
  CTID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)              NOT NULL ,
  PAID                               RAW(16)              NOT NULL ,
  VARIABLE_NAME                      VARCHAR2(254)        NOT NULL ,
  PROPERTY_NAME                      VARCHAR2(255)        NOT NULL ,
  PROPERTY_NAMESPACE                 VARCHAR2(254)        NOT NULL ,
  TYPE                               NUMBER(10,0)         NOT NULL ,
  GENERIC_VALUE                      VARCHAR2(512)                 ,
  STRING_VALUE                       VARCHAR2(512)                 ,
  NUMBER_VALUE                       NUMBER(20,0)                  ,
  DECIMAL_VALUE                      NUMBER                        ,
  TIMESTAMP_VALUE                    TIMESTAMP                     ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.QUERYABLE_VARIABLE_INSTANCE_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.QVI_PI_CT_PA ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, CTID, PAID
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_VARNAME ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, VARIABLE_NAME
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_PROPNAME ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, PROPERTY_NAME
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_NAMESPACE ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, PROPERTY_NAMESPACE
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_GEN_VALUE ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, GENERIC_VALUE
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_STR_VALUE ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, STRING_VALUE
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_NUM ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, NUMBER_VALUE
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_DEC ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, DECIMAL_VALUE
) LOGGING;

CREATE INDEX bpcdb.QVI_PI_TIME ON bpcdb.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, TIMESTAMP_VALUE
) LOGGING;

CREATE TABLE bpcdb.SYNC_T
(
  IDENTIFIER                         VARCHAR2(254)        NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SYNC_T ADD(
  PRIMARY KEY ( IDENTIFIER )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.MV_CTR_T
(
  ID                                 NUMBER(10,0)         NOT NULL ,
  SELECT_CLAUSE                      VARCHAR2(1024)       NOT NULL ,
  WHERE_CLAUSE                       VARCHAR2(1024)                ,
  ORDER_CLAUSE                       VARCHAR2(512)                 ,
  TBL_SPACE                          VARCHAR2(32)         NOT NULL ,
  UPDATED                            TIMESTAMP            NOT NULL ,
  UPD_STARTED                        TIMESTAMP                     ,
  AVG_UPD_TIME                       NUMBER(20,0)                  ,
  UPD_INTERVAL                       NUMBER(20,0)         NOT NULL ,
  IS_UPDATING                        NUMBER(5,0)          NOT NULL ,
  ACTIVE_MV                          NUMBER(5,0)          NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.MV_CTR_T ADD(
  PRIMARY KEY ( ID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.MV_MODS_T
(
  PKID                               RAW(16)              NOT NULL ,
  OID                                RAW(16)              NOT NULL ,
  MODIFIED                           TIMESTAMP            NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.MV_MODS_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.SAVED_ENGINE_MESSAGE_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)                       ,
  CREATION_TIME                      TIMESTAMP            NOT NULL ,
  REASON                             NUMBER(10,0)         NOT NULL ,
  ENGINE_MESSAGE_S                   RAW(2000)                     ,
  ENGINE_MESSAGE_L                   BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SAVED_ENGINE_MESSAGE_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SEM_PIID ON bpcdb.SAVED_ENGINE_MESSAGE_B_T
(   
  PIID
) LOGGING;

CREATE INDEX bpcdb.SEM_REAS ON bpcdb.SAVED_ENGINE_MESSAGE_B_T
(   
  REASON
) LOGGING;

CREATE TABLE bpcdb.NAVIGATION_CLEANUP_TIMER_B_T
(
  PKID                               RAW(16)              NOT NULL ,
  SCHEDULED_TIME                     TIMESTAMP            NOT NULL ,
  SCHEDULER_ID                       VARCHAR2(254)        NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.NAVIGATION_CLEANUP_TIMER_B_T ADD(
  PRIMARY KEY ( PKID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.SCHEDULER_ACTION_T
(
  SCHEDULER_ID                       VARCHAR2(254)        NOT NULL ,
  OID                                RAW(16)              NOT NULL ,
  ACTION_OBJECT                      BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.SCHEDULER_ACTION_T ADD(
  PRIMARY KEY ( SCHEDULER_ID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SCEACT_OID ON bpcdb.SCHEDULER_ACTION_T
(   
  OID
) LOGGING;

CREATE TABLE bpcdb.AUDIT_LOG_T
(
  ALID                               RAW(16)              NOT NULL ,
  EVENT_TIME                         TIMESTAMP            NOT NULL ,
  EVENT_TIME_UTC                     TIMESTAMP                     ,
  AUDIT_EVENT                        NUMBER(10,0)         NOT NULL ,
  PTID                               RAW(16)              NOT NULL ,
  PIID                               RAW(16)                       ,
  AIID                               RAW(16)                       ,
  SIID                               RAW(16)                       ,
  VARIABLE_NAME                      VARCHAR2(254)                 ,
  PROCESS_TEMPL_NAME                 VARCHAR2(254)        NOT NULL ,
  PROCESS_INST_NAME                  VARCHAR2(254)                 ,
  TOP_LEVEL_PI_NAME                  VARCHAR2(254)                 ,
  TOP_LEVEL_PIID                     RAW(16)                       ,
  PARENT_PI_NAME                     VARCHAR2(254)                 ,
  PARENT_PIID                        RAW(16)                       ,
  VALID_FROM                         TIMESTAMP                     ,
  VALID_FROM_UTC                     TIMESTAMP                     ,
  ATID                               RAW(16)                       ,
  ACTIVITY_NAME                      VARCHAR2(254)                 ,
  ACTIVITY_KIND                      NUMBER(10,0)                  ,
  ACTIVITY_STATE                     NUMBER(10,0)                  ,
  CONTROL_LINK_NAME                  VARCHAR2(254)                 ,
  IMPL_NAME                          VARCHAR2(254)                 ,
  PRINCIPAL                          VARCHAR2(128)                 ,
  TERMINAL_NAME                      VARCHAR2(254)                 ,
  VARIABLE_DATA                      BLOB                          ,
  EXCEPTION_TEXT                     CLOB                          ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  CORR_SET_INFO                      CLOB                          ,
  USER_NAME                          VARCHAR2(128)                 ,
  ADDITIONAL_INFO                    CLOB                          ,
  OBJECT_META_TYPE                   NUMBER(10,0)                  ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.AUDIT_LOG_T ADD(
  PRIMARY KEY ( ALID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.WORK_ITEM_T
(
  WIID                               RAW(16)              NOT NULL ,
  PARENT_WIID                        RAW(16)                       ,
  OWNER_ID                           VARCHAR2(128)                 ,
  GROUP_NAME                         VARCHAR2(128)                 ,
  EVERYBODY                          NUMBER(5,0)          NOT NULL ,
  EXCLUDE                            NUMBER(5,0)          NOT NULL ,
  QIID                               RAW(16)                       ,
  OBJECT_TYPE                        NUMBER(10,0)         NOT NULL ,
  OBJECT_ID                          RAW(16)              NOT NULL ,
  ASSOCIATED_OBJECT_TYPE             NUMBER(10,0)         NOT NULL ,
  ASSOCIATED_OID                     RAW(16)                       ,
  REASON                             NUMBER(10,0)         NOT NULL ,
  CREATION_TIME                      TIMESTAMP            NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  AUTH_INFO                          NUMBER(10,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.WORK_ITEM_T ADD(
  PRIMARY KEY ( WIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.WI_ASSOBJ_REASON ON bpcdb.WORK_ITEM_T
(   
  ASSOCIATED_OID, ASSOCIATED_OBJECT_TYPE, REASON, PARENT_WIID
) LOGGING;

CREATE INDEX bpcdb.WI_OBJID_TYPE_QIID ON bpcdb.WORK_ITEM_T
(   
  OBJECT_ID, OBJECT_TYPE, QIID
) LOGGING;

CREATE INDEX bpcdb.WI_OBJID_TYPE_REAS ON bpcdb.WORK_ITEM_T
(   
  OBJECT_ID, OBJECT_TYPE, REASON
) LOGGING;

CREATE INDEX bpcdb.WI_GROUP_NAME ON bpcdb.WORK_ITEM_T
(   
  GROUP_NAME
) LOGGING;

CREATE INDEX bpcdb.WI_AUTH_L ON bpcdb.WORK_ITEM_T
(   
  EVERYBODY, GROUP_NAME, OWNER_ID, QIID
) LOGGING;

CREATE INDEX bpcdb.WI_AUTH_S ON bpcdb.WORK_ITEM_T
(   
  EVERYBODY, GROUP_NAME, OWNER_ID
) LOGGING;

CREATE INDEX bpcdb.WI_EVERYBODY ON bpcdb.WORK_ITEM_T
(   
  EVERYBODY
) LOGGING;

CREATE INDEX bpcdb.WI_REASON ON bpcdb.WORK_ITEM_T
(   
  REASON
) LOGGING;

CREATE INDEX bpcdb.WI_OWNER ON bpcdb.WORK_ITEM_T
(   
  OWNER_ID, OBJECT_ID, REASON, OBJECT_TYPE
) LOGGING;

CREATE INDEX bpcdb.WI_QIID ON bpcdb.WORK_ITEM_T
(   
  QIID
) LOGGING;

CREATE INDEX bpcdb.WI_QRY ON bpcdb.WORK_ITEM_T
(   
  OBJECT_ID, REASON, EVERYBODY, OWNER_ID
) LOGGING;

CREATE INDEX bpcdb.WI_QI_OID_RS_OWN ON bpcdb.WORK_ITEM_T
(   
  QIID, OBJECT_ID, REASON, OWNER_ID
) LOGGING;

CREATE INDEX bpcdb.WI_QI_OID_OWN ON bpcdb.WORK_ITEM_T
(   
  QIID, OBJECT_ID, OWNER_ID
) LOGGING;

CREATE INDEX bpcdb.WI_OT_OID_RS ON bpcdb.WORK_ITEM_T
(   
  OBJECT_TYPE, OBJECT_ID, REASON
) LOGGING;

CREATE INDEX bpcdb.WI_WI_QI ON bpcdb.WORK_ITEM_T
(   
  WIID, QIID
) LOGGING;

CREATE TABLE bpcdb.WI_ASSOC_OID_T
(
  WIID                               RAW(16)              NOT NULL ,
  OBJECT_ID                          RAW(16)              NOT NULL ,
  OBJECT_TYPE                        NUMBER(10,0)         NOT NULL ,
  ASSOCIATED_OID                     RAW(16)              NOT NULL ,
  REASON                             NUMBER(10,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.WI_ASSOC_OID_T ADD(
  PRIMARY KEY ( WIID, OBJECT_ID, REASON )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.WIASS_OIDR ON bpcdb.WI_ASSOC_OID_T
(   
  OBJECT_ID, REASON, OBJECT_TYPE
) LOGGING;

CREATE INDEX bpcdb.WIASS_ASSOC ON bpcdb.WI_ASSOC_OID_T
(   
  ASSOCIATED_OID
) LOGGING;

CREATE INDEX bpcdb.WIASS_WI ON bpcdb.WI_ASSOC_OID_T
(   
  WIID
) LOGGING;

CREATE TABLE bpcdb.RETRIEVED_USER_T
(
  QIID                               RAW(16)              NOT NULL ,
  OWNER_ID                           VARCHAR2(128)        NOT NULL ,
  REASON                             NUMBER(10,0)         NOT NULL ,
  ASSOCIATED_OID                     RAW(16)                       ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.RETRIEVED_USER_T ADD(
  PRIMARY KEY ( QIID, OWNER_ID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.RUT_OWN_QIID ON bpcdb.RETRIEVED_USER_T
(   
  OWNER_ID, QIID
) LOGGING;

CREATE INDEX bpcdb.RUT_ASSOC ON bpcdb.RETRIEVED_USER_T
(   
  ASSOCIATED_OID
) LOGGING;

CREATE INDEX bpcdb.RUT_QIID ON bpcdb.RETRIEVED_USER_T
(   
  QIID
) LOGGING;

CREATE INDEX bpcdb.RUT_OWN_QIDESC ON bpcdb.RETRIEVED_USER_T
(   
  OWNER_ID, QIID DESC
) LOGGING;

CREATE TABLE bpcdb.STAFF_QUERY_INSTANCE_T
(
  QIID                               RAW(16)              NOT NULL ,
  QTID                               RAW(16)              NOT NULL ,
  EVERYBODY                          NUMBER(5,0)          NOT NULL ,
  NOBODY                             NUMBER(5,0)          NOT NULL ,
  IS_SHAREABLE                       NUMBER(5,0)          NOT NULL ,
  IS_TRANSFERRED                     NUMBER(5,0)          NOT NULL ,
  SR_HASH_CODE                       NUMBER(10,0)                  ,
  GROUP_NAME                         VARCHAR2(128)                 ,
  CONTEXT_VALUES                     VARCHAR2(3072)                ,
  CONTEXT_VALUES_LONG                CLOB                          ,
  HASH_CODE                          NUMBER(10,0)                  ,
  EXPIRES                            TIMESTAMP                     ,
  ASSOCIATED_OBJECT_TYPE             NUMBER(10,0)         NOT NULL ,
  ASSOCIATED_OID                     RAW(16)              NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.STAFF_QUERY_INSTANCE_T ADD(
  PRIMARY KEY ( QIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.SQI_QTID ON bpcdb.STAFF_QUERY_INSTANCE_T
(   
  QTID, HASH_CODE
) LOGGING;

CREATE INDEX bpcdb.SQI_ASSOCID ON bpcdb.STAFF_QUERY_INSTANCE_T
(   
  ASSOCIATED_OID, ASSOCIATED_OBJECT_TYPE
) LOGGING;

CREATE INDEX bpcdb.SQI_QIIDGN ON bpcdb.STAFF_QUERY_INSTANCE_T
(   
  QIID, GROUP_NAME
) LOGGING;

CREATE INDEX bpcdb.SQI_QIIDTREX ON bpcdb.STAFF_QUERY_INSTANCE_T
(   
  QIID, IS_TRANSFERRED, EXPIRES
) LOGGING;

CREATE TABLE bpcdb.STAFF_LOCK_T
(
  QTID                               RAW(16)              NOT NULL ,
  HASH_CODE                          NUMBER(10,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.STAFF_LOCK_T ADD(
  PRIMARY KEY ( QTID, HASH_CODE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.COORDINATOR
(
  UUIDFLD                            VARCHAR2(40)         NOT NULL ,
  CLOSEBEHAVIOURFLD                  NUMBER(10,0)         NOT NULL ,
  COORDINATORSTATE                   NUMBER(10,0)         NOT NULL ,
  SYNCLISTFLD                        BLOB                          ,
  DIRECTIONFLD                       NUMBER(10,0)                  ,
  COORDINATORHOMEFLD                 VARCHAR2(100)                 ,
  EXECUTORHOMEFLD                    VARCHAR2(100)                 ,
  EXECUTORFLD                        VARCHAR2(40)                  ,
  NAMEFLD                            VARCHAR2(100)                 ,
  PARENTUUIDFLD                      VARCHAR2(40)                  ,
  LASTTIMEFLD                        NUMBER(20,0)         NOT NULL ,
  CREATIONTIMEFLD                    NUMBER(20,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.COORDINATOR ADD(
  PRIMARY KEY ( UUIDFLD )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.STANDARDEXECUTOR
(
  UUIDFLD                            VARCHAR2(40)         NOT NULL ,
  EXECUTORSTATEFLD                   NUMBER(10,0)         NOT NULL ,
  DIRECTIONFLD                       NUMBER(10,0)                  ,
  PROCEEDSTRINGFLD                   VARCHAR2(40)                  ,
  EXECUTORHOMEFLD                    VARCHAR2(100)                 ,
  COORDINATORHOMEFLD                 VARCHAR2(100)                 ,
  COORDINATORKEYFLD                  VARCHAR2(40)                  ,
  NAMEFLD                            VARCHAR2(100)                 ,
  LASTTIMEFLD                        NUMBER(20,0)         NOT NULL ,
  CREATIONTIMEFLD                    NUMBER(20,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.STANDARDEXECUTOR ADD(
  PRIMARY KEY ( UUIDFLD )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.CONTEXTUALPROCLET
(
  UUIDFLD                            VARCHAR2(40)         NOT NULL ,
  COORDINATORHOME                    VARCHAR2(100)        NOT NULL ,
  COORDINATORKEY                     VARCHAR2(40)         NOT NULL ,
  WORKWITHCONTEXT                    BLOB                          ,
  NAME                               VARCHAR2(100)                 ,
  ELEMENTID                          VARCHAR2(100)                 ,
  PROCLETSTATE                       NUMBER(10,0)         NOT NULL ,
  ISINTERESTEDACCEPT                 NUMBER(5,0)          NOT NULL ,
  ISINTERESTEDREJECT                 NUMBER(5,0)          NOT NULL ,
  PRIMARYSTARTTIME                   NUMBER(20,0)                  ,
  PRIMARYENDTIME                     NUMBER(20,0)                  ,
  COMPSTARTTIME                      NUMBER(20,0)                  ,
  COMPENDTIME                        NUMBER(20,0)                  ,
  REASON                             BLOB                          ,
  LASTTIME                           NUMBER(20,0)         NOT NULL ,
  CREATIONTIME                       NUMBER(20,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CONTEXTUALPROCLET ADD(
  PRIMARY KEY ( UUIDFLD )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CP_COORDHOME ON bpcdb.CONTEXTUALPROCLET
(   
  COORDINATORHOME
) LOGGING;

CREATE TABLE bpcdb.BLOB4K
(
  UUIDFLD                            VARCHAR2(40)         NOT NULL ,
  OWNERKEY                           VARCHAR2(40)         NOT NULL ,
  FIELDID                            NUMBER(10,0)         NOT NULL ,
  SECTIONID                          NUMBER(10,0)         NOT NULL ,
  THEBYTES                           BLOB                 NOT NULL ,
  LASTTIME                           NUMBER(20,0)         NOT NULL ,
  CREATIONTIME                       NUMBER(20,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.BLOB4K ADD(
  PRIMARY KEY ( UUIDFLD )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.APPLICATION_COMPONENT_T
(
  ACOID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(64)         NOT NULL ,
  CALENDAR_NAME                      VARCHAR2(254)                 ,
  JNDI_NAME_CALENDAR                 VARCHAR2(254)                 ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR2(254)        NOT NULL ,
  DURATION_UNTIL_DELETED             VARCHAR2(254)                 ,
  EVENT_HANDLER_NAME                 VARCHAR2(64)                  ,
  INSTANCE_CREATOR_QTID              RAW(16)                       ,
  SUPPORTS_AUTO_CLAIM                NUMBER(5,0)          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            NUMBER(5,0)          NOT NULL ,
  SUPPORTS_CLAIM_SUSPENDED           NUMBER(5,0)          NOT NULL ,
  SUPPORTS_DELEGATION                NUMBER(5,0)          NOT NULL ,
  SUPPORTS_SUB_TASK                  NUMBER(5,0)          NOT NULL ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  SUBSTITUTION_POLICY                NUMBER(10,0)         NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.APPLICATION_COMPONENT_T ADD(
  PRIMARY KEY ( ACOID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.ACO_NAME ON bpcdb.APPLICATION_COMPONENT_T
(   
  NAME
) LOGGING;

CREATE TABLE bpcdb.ESCALATION_TEMPLATE_T
(
  ESTID                              RAW(16)              NOT NULL ,
  FIRST_ESTID                        RAW(16)                       ,
  PREVIOUS_ESTID                     RAW(16)                       ,
  TKTID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  MNTID                              RAW(16)                       ,
  NAME                               VARCHAR2(220)                 ,
  ACTIVATION_STATE                   NUMBER(10,0)         NOT NULL ,
  AT_LEAST_EXPECTED_STATE            NUMBER(10,0)         NOT NULL ,
  DURATION_UNTIL_ESCALATION          VARCHAR2(254)                 ,
  DURATION_UNTIL_REPEATS             VARCHAR2(254)                 ,
  INCREASE_PRIORITY                  NUMBER(10,0)         NOT NULL ,
  ACTION                             NUMBER(10,0)         NOT NULL ,
  ESCALATION_RECEIVER_QTID           RAW(16)                       ,
  RECEIVER_EMAIL_QTID                RAW(16)                       
) LOGGING;

ALTER TABLE bpcdb.ESCALATION_TEMPLATE_T ADD(
  PRIMARY KEY ( ESTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ET_TKTID ON bpcdb.ESCALATION_TEMPLATE_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.ET_CCID ON bpcdb.ESCALATION_TEMPLATE_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.ESC_TEMPL_CPROP_T
(
  ESTID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  TKTID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  STRING_VALUE                       VARCHAR2(254)                 ,
  DATA_TYPE                          VARCHAR2(254)                 ,
  DATA                               BLOB                          
) LOGGING;

ALTER TABLE bpcdb.ESC_TEMPL_CPROP_T ADD(
  PRIMARY KEY ( ESTID, NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ETCP_TKTID ON bpcdb.ESC_TEMPL_CPROP_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.ETCP_CCID ON bpcdb.ESC_TEMPL_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.ESC_TEMPL_LDESC_T
(
  ESTID                              RAW(16)              NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  TKTID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DISPLAY_NAME                       VARCHAR2(64)                  ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  DOCUMENTATION                      CLOB                          
) LOGGING;

ALTER TABLE bpcdb.ESC_TEMPL_LDESC_T ADD(
  PRIMARY KEY ( ESTID, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ETLD_TKTID ON bpcdb.ESC_TEMPL_LDESC_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.ETLD_CCID ON bpcdb.ESC_TEMPL_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TTASK_MESSAGE_DEFINITION_T
(
  TMTID                              RAW(16)              NOT NULL ,
  TKTID                              RAW(16)                       ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  FAULT_NAME                         VARCHAR2(254)                 ,
  MESSAGE_TYPE_NS                    VARCHAR2(220)        NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR2(220)        NOT NULL ,
  MESSAGE_DEFINITION                 BLOB                          
) LOGGING;

ALTER TABLE bpcdb.TTASK_MESSAGE_DEFINITION_T ADD(
  PRIMARY KEY ( TMTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TTMD_TKTID ON bpcdb.TTASK_MESSAGE_DEFINITION_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.TTMD_CCID ON bpcdb.TTASK_MESSAGE_DEFINITION_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_TEMPLATE_T
(
  TKTID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  DEFINITION_NAME                    VARCHAR2(220)        NOT NULL ,
  NAMESPACE                          VARCHAR2(254)        NOT NULL ,
  TARGET_NAMESPACE                   VARCHAR2(254)        NOT NULL ,
  VALID_FROM                         TIMESTAMP            NOT NULL ,
  APPLICATION_NAME                   VARCHAR2(220)                 ,
  APPLICATION_DEFAULTS_ID            RAW(16)                       ,
  CONTAINMENT_CONTEXT_ID             RAW(16)                       ,
  SVTID                              RAW(16)                       ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  AUTO_DELETE_MODE                   NUMBER(10,0)         NOT NULL ,
  IS_AD_HOC                          NUMBER(5,0)          NOT NULL ,
  IS_INLINE                          NUMBER(5,0)          NOT NULL ,
  IS_SHARED                          NUMBER(5,0)          NOT NULL ,
  SUPPORTS_CLAIM_SUSPENDED           NUMBER(5,0)          NOT NULL ,
  SUPPORTS_AUTO_CLAIM                NUMBER(5,0)          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            NUMBER(5,0)          NOT NULL ,
  SUPPORTS_DELEGATION                NUMBER(5,0)          NOT NULL ,
  SUPPORTS_SUB_TASK                  NUMBER(5,0)          NOT NULL ,
  CONTEXT_AUTHORIZATION              NUMBER(10,0)         NOT NULL ,
  ADMIN_QTID                         RAW(16)                       ,
  EDITOR_QTID                        RAW(16)                       ,
  INSTANCE_CREATOR_QTID              RAW(16)                       ,
  POTENTIAL_STARTER_QTID             RAW(16)                       ,
  POTENTIAL_OWNER_QTID               RAW(16)                       ,
  READER_QTID                        RAW(16)                       ,
  DEFAULT_LOCALE                     VARCHAR2(32)                  ,
  CALENDAR_NAME                      VARCHAR2(254)                 ,
  DURATION_UNTIL_DELETED             VARCHAR2(254)                 ,
  DURATION_UNTIL_DUE                 VARCHAR2(254)                 ,
  DURATION_UNTIL_EXPIRES             VARCHAR2(254)                 ,
  JNDI_NAME_CALENDAR                 VARCHAR2(254)                 ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR2(254)        NOT NULL ,
  TYPE                               VARCHAR2(254)                 ,
  EVENT_HANDLER_NAME                 VARCHAR2(64)                  ,
  PRIORITY                           NUMBER(10,0)                  ,
  PRIORITY_DEFINITION                VARCHAR2(254)                 ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  SUBSTITUTION_POLICY                NUMBER(10,0)         NOT NULL ,
  CONTACTS_QTIDS                     BLOB                          ,
  UI_SETTINGS                        BLOB                          
) LOGGING;

ALTER TABLE bpcdb.TASK_TEMPLATE_T ADD(
  PRIMARY KEY ( TKTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE UNIQUE INDEX bpcdb.TT_NAME_VF_NS ON bpcdb.TASK_TEMPLATE_T
(   
  NAME, VALID_FROM, NAMESPACE
) LOGGING;

CREATE INDEX bpcdb.TT_CCID_STATE ON bpcdb.TASK_TEMPLATE_T
(   
  CONTAINMENT_CONTEXT_ID, STATE
) LOGGING;

CREATE INDEX bpcdb.TT_KND_INLN_VAL ON bpcdb.TASK_TEMPLATE_T
(   
  KIND, IS_INLINE, VALID_FROM
) LOGGING;

CREATE TABLE bpcdb.TASK_TEMPL_CPROP_T
(
  TKTID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DATA_TYPE                          VARCHAR2(254)                 ,
  STRING_VALUE                       VARCHAR2(254)                 ,
  DATA                               BLOB                          
) LOGGING;

ALTER TABLE bpcdb.TASK_TEMPL_CPROP_T ADD(
  PRIMARY KEY ( TKTID, NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TTCP_TKTID ON bpcdb.TASK_TEMPL_CPROP_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.TTCP_CCID ON bpcdb.TASK_TEMPL_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_TEMPL_LDESC_T
(
  TKTID                              RAW(16)              NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DISPLAY_NAME                       VARCHAR2(64)                  ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  DOCUMENTATION                      CLOB                          
) LOGGING;

ALTER TABLE bpcdb.TASK_TEMPL_LDESC_T ADD(
  PRIMARY KEY ( TKTID, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TTLD_TKTID ON bpcdb.TASK_TEMPL_LDESC_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.TTLD_CCID ON bpcdb.TASK_TEMPL_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE INDEX bpcdb.TTLD_TT_LOC ON bpcdb.TASK_TEMPL_LDESC_T
(   
  TKTID, LOCALE DESC
) LOGGING;

CREATE TABLE bpcdb.TSERVICE_DESCRIPTION_T
(
  SVTID                              RAW(16)              NOT NULL ,
  TKTID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  IS_ONE_WAY                         NUMBER(5,0)          NOT NULL ,
  SERVICE_REF_NAME                   VARCHAR2(254)                 ,
  OPERATION                          VARCHAR2(254)        NOT NULL ,
  PORT                               VARCHAR2(254)                 ,
  PORT_TYPE_NS                       VARCHAR2(254)        NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR2(254)        NOT NULL ,
  S_BEAN_JNDI_NAME                   VARCHAR2(254)                 ,
  SERVICE                            VARCHAR2(254)                 
) LOGGING;

ALTER TABLE bpcdb.TSERVICE_DESCRIPTION_T ADD(
  PRIMARY KEY ( SVTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TSD_TKTID ON bpcdb.TSERVICE_DESCRIPTION_T
(   
  TKTID
) LOGGING;

CREATE INDEX bpcdb.TSD_CCID ON bpcdb.TSERVICE_DESCRIPTION_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_CELL_MAP_T
(
  TKTID                              RAW(16)              NOT NULL ,
  CELL                               VARCHAR2(220)        NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_CELL_MAP_T ADD(
  PRIMARY KEY ( TKTID, CELL )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.TMAIL_T
(
  MNTID                              RAW(16)              NOT NULL ,
  FROM_STATE                         NUMBER(10,0)         NOT NULL ,
  TO_STATE                           NUMBER(10,0)         NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  HASH_CODE                          NUMBER(10,0)         NOT NULL ,
  SUBJECT                            VARCHAR2(254)        NOT NULL ,
  BODY_TEXT                          CLOB                          
) LOGGING;

ALTER TABLE bpcdb.TMAIL_T ADD(
  PRIMARY KEY ( MNTID, FROM_STATE, TO_STATE, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EMT_HC ON bpcdb.TMAIL_T
(   
  HASH_CODE
) LOGGING;

CREATE TABLE bpcdb.ESCALATION_INSTANCE_T
(
  ESIID                              RAW(16)              NOT NULL ,
  ESTID                              RAW(16)                       ,
  FIRST_ESIID                        RAW(16)                       ,
  PREVIOUS_ESIID                     RAW(16)                       ,
  TKIID                              RAW(16)              NOT NULL ,
  MNTID                              RAW(16)                       ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)                 ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  ACTIVATION_STATE                   NUMBER(10,0)         NOT NULL ,
  AT_LEAST_EXPECTED_STATE            NUMBER(10,0)         NOT NULL ,
  ACTIVATION_TIME                    TIMESTAMP                     ,
  DURATION_UNTIL_ESCALATION          VARCHAR2(254)                 ,
  DURATION_UNTIL_REPEATS             VARCHAR2(254)                 ,
  INCREASE_PRIORITY                  NUMBER(10,0)         NOT NULL ,
  ACTION                             NUMBER(10,0)         NOT NULL ,
  ESCALATION_RECEIVER_QTID           RAW(16)                       ,
  RECEIVER_EMAIL_QTID                RAW(16)                       ,
  SCHEDULER_ID                       VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ESCALATION_INSTANCE_T ADD(
  PRIMARY KEY ( ESIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ESI_FIRST ON bpcdb.ESCALATION_INSTANCE_T
(   
  FIRST_ESIID
) LOGGING;

CREATE INDEX bpcdb.ESI_TKIID_ASTATE ON bpcdb.ESCALATION_INSTANCE_T
(   
  TKIID, ACTIVATION_STATE, STATE
) LOGGING;

CREATE INDEX bpcdb.ESI_TKIID_STATE ON bpcdb.ESCALATION_INSTANCE_T
(   
  TKIID, STATE
) LOGGING;

CREATE INDEX bpcdb.ESI_PREV ON bpcdb.ESCALATION_INSTANCE_T
(   
  PREVIOUS_ESIID
) LOGGING;

CREATE INDEX bpcdb.ESI_ESTID ON bpcdb.ESCALATION_INSTANCE_T
(   
  ESTID
) LOGGING;

CREATE INDEX bpcdb.ESI_CCID ON bpcdb.ESCALATION_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE INDEX bpcdb.ESI_EST_ESI ON bpcdb.ESCALATION_INSTANCE_T
(   
  ESTID, ESIID
) LOGGING;

CREATE TABLE bpcdb.ESC_INST_CPROP_T
(
  ESIID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  STRING_VALUE                       VARCHAR2(254)                 ,
  DATA_TYPE                          VARCHAR2(254)                 ,
  DATA                               BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ESC_INST_CPROP_T ADD(
  PRIMARY KEY ( ESIID, NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EICP_CCID ON bpcdb.ESC_INST_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.ESC_INST_LDESC_T
(
  ESIID                              RAW(16)              NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DISPLAY_NAME                       VARCHAR2(64)                  ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ESC_INST_LDESC_T ADD(
  PRIMARY KEY ( ESIID, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EILD_CCID ON bpcdb.ESC_INST_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.EIDOCUMENTATION_T
(
  ESIID                              RAW(16)              NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DOCUMENTATION                      CLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.EIDOCUMENTATION_T ADD(
  PRIMARY KEY ( ESIID, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.EIDOC_CCID ON bpcdb.EIDOCUMENTATION_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.ISERVICE_DESCRIPTION_T
(
  SVTID                              RAW(16)              NOT NULL ,
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  IS_ONE_WAY                         NUMBER(5,0)          NOT NULL ,
  SERVICE_REF_NAME                   VARCHAR2(254)                 ,
  OPERATION                          VARCHAR2(254)        NOT NULL ,
  PORT                               VARCHAR2(254)                 ,
  PORT_TYPE_NS                       VARCHAR2(254)        NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR2(254)        NOT NULL ,
  S_BEAN_JNDI_NAME                   VARCHAR2(254)                 ,
  SERVICE                            VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ISERVICE_DESCRIPTION_T ADD(
  PRIMARY KEY ( SVTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ISD_TKIID ON bpcdb.ISERVICE_DESCRIPTION_T
(   
  TKIID
) LOGGING;

CREATE INDEX bpcdb.ISD_CCID ON bpcdb.ISERVICE_DESCRIPTION_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_INSTANCE_T
(
  TKIID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  NAMESPACE                          VARCHAR2(254)        NOT NULL ,
  TKTID                              RAW(16)                       ,
  TOP_TKIID                          RAW(16)              NOT NULL ,
  FOLLOW_ON_TKIID                    RAW(16)                       ,
  APPLICATION_NAME                   VARCHAR2(220)                 ,
  APPLICATION_DEFAULTS_ID            RAW(16)                       ,
  CONTAINMENT_CONTEXT_ID             RAW(16)                       ,
  PARENT_CONTEXT_ID                  RAW(16)                       ,
  STATE                              NUMBER(10,0)         NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  AUTO_DELETE_MODE                   NUMBER(10,0)         NOT NULL ,
  HIERARCHY_POSITION                 NUMBER(10,0)         NOT NULL ,
  TYPE                               VARCHAR2(254)                 ,
  SVTID                              RAW(16)                       ,
  SUPPORTS_CLAIM_SUSPENDED           NUMBER(5,0)          NOT NULL ,
  SUPPORTS_AUTO_CLAIM                NUMBER(5,0)          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            NUMBER(5,0)          NOT NULL ,
  IS_AD_HOC                          NUMBER(5,0)          NOT NULL ,
  IS_ESCALATED                       NUMBER(5,0)          NOT NULL ,
  IS_INLINE                          NUMBER(5,0)          NOT NULL ,
  IS_SUSPENDED                       NUMBER(5,0)          NOT NULL ,
  IS_WAITING_FOR_SUBTASK             NUMBER(5,0)          NOT NULL ,
  SUPPORTS_DELEGATION                NUMBER(5,0)          NOT NULL ,
  SUPPORTS_SUB_TASK                  NUMBER(5,0)          NOT NULL ,
  START_TIME                         TIMESTAMP                     ,
  ACTIVATION_TIME                    TIMESTAMP                     ,
  LAST_MODIFICATION_TIME             TIMESTAMP                     ,
  LAST_STATE_CHANGE_TIME             TIMESTAMP                     ,
  COMPLETION_TIME                    TIMESTAMP                     ,
  DUE_TIME                           TIMESTAMP                     ,
  EXPIRATION_TIME                    TIMESTAMP                     ,
  FIRST_ACTIVATION_TIME              TIMESTAMP                     ,
  DEFAULT_LOCALE                     VARCHAR2(32)                  ,
  DURATION_UNTIL_DELETED             VARCHAR2(254)                 ,
  DURATION_UNTIL_DUE                 VARCHAR2(254)                 ,
  DURATION_UNTIL_EXPIRES             VARCHAR2(254)                 ,
  CALENDAR_NAME                      VARCHAR2(254)                 ,
  JNDI_NAME_CALENDAR                 VARCHAR2(254)                 ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR2(254)                 ,
  CONTEXT_AUTHORIZATION              NUMBER(10,0)         NOT NULL ,
  ORIGINATOR                         VARCHAR2(128)                 ,
  STARTER                            VARCHAR2(128)                 ,
  OWNER                              VARCHAR2(128)                 ,
  ADMIN_QTID                         RAW(16)                       ,
  EDITOR_QTID                        RAW(16)                       ,
  POTENTIAL_OWNER_QTID               RAW(16)                       ,
  POTENTIAL_STARTER_QTID             RAW(16)                       ,
  READER_QTID                        RAW(16)                       ,
  PRIORITY                           NUMBER(10,0)                  ,
  SCHEDULER_ID                       VARCHAR2(254)                 ,
  SERVICE_TICKET                     VARCHAR2(254)                 ,
  EVENT_HANDLER_NAME                 VARCHAR2(64)                  ,
  BUSINESS_RELEVANCE                 NUMBER(5,0)          NOT NULL ,
  RESUMES                            TIMESTAMP                     ,
  SUBSTITUTION_POLICY                NUMBER(10,0)         NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_INSTANCE_T ADD(
  PRIMARY KEY ( TKIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TI_PARENT ON bpcdb.TASK_INSTANCE_T
(   
  PARENT_CONTEXT_ID
) LOGGING;

CREATE INDEX bpcdb.TI_ACOID ON bpcdb.TASK_INSTANCE_T
(   
  APPLICATION_DEFAULTS_ID
) LOGGING;

CREATE INDEX bpcdb.TI_NAME ON bpcdb.TASK_INSTANCE_T
(   
  NAME
) LOGGING;

CREATE INDEX bpcdb.TI_STATE ON bpcdb.TASK_INSTANCE_T
(   
  STATE
) LOGGING;

CREATE INDEX bpcdb.TI_SERVICET ON bpcdb.TASK_INSTANCE_T
(   
  SERVICE_TICKET
) LOGGING;

CREATE INDEX bpcdb.TI_CCID ON bpcdb.TASK_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE INDEX bpcdb.TI_TK_TOPTK ON bpcdb.TASK_INSTANCE_T
(   
  TKTID, TKIID, TOP_TKIID
) LOGGING;

CREATE INDEX bpcdb.TI_TOPTKIID ON bpcdb.TASK_INSTANCE_T
(   
  TOP_TKIID
) LOGGING;

CREATE INDEX bpcdb.TI_TI_TT_KND_ST ON bpcdb.TASK_INSTANCE_T
(   
  TKIID, TKTID, KIND, STATE
) LOGGING;

CREATE INDEX bpcdb.TI_TI_KND_ST ON bpcdb.TASK_INSTANCE_T
(   
  TKIID, KIND, STATE
) LOGGING;

CREATE INDEX bpcdb.TI_TI_KND_ORIG ON bpcdb.TASK_INSTANCE_T
(   
  TKIID, KIND, ORIGINATOR
) LOGGING;

CREATE INDEX bpcdb.TI_TI_KND_STRT ON bpcdb.TASK_INSTANCE_T
(   
  TKIID, KIND, STARTER
) LOGGING;

CREATE INDEX bpcdb.TI_TI_ORIG_KND ON bpcdb.TASK_INSTANCE_T
(   
  TKIID, ORIGINATOR, KIND
) LOGGING;

CREATE INDEX bpcdb.TI_TI_KND ON bpcdb.TASK_INSTANCE_T
(   
  TKIID, KIND
) LOGGING;

CREATE INDEX bpcdb.TI_PAR_KND ON bpcdb.TASK_INSTANCE_T
(   
  PARENT_CONTEXT_ID, KIND
) LOGGING;

CREATE INDEX bpcdb.TI_KND_TOP_TI ON bpcdb.TASK_INSTANCE_T
(   
  KIND, TOP_TKIID, TKIID
) LOGGING;

CREATE INDEX bpcdb.TI_PRI_ATM_KND ON bpcdb.TASK_INSTANCE_T
(   
  PRIORITY, ACTIVATION_TIME DESC, KIND
) LOGGING;

CREATE TABLE bpcdb.TASK_CONTEXT_T
(
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  SERVICE_CONTEXT                    BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_CONTEXT_T ADD(
  PRIMARY KEY ( TKIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TC_CCID ON bpcdb.TASK_CONTEXT_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.CONTACT_QUERIES_T
(
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  CONTACTS_QTIDS                     BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.CONTACT_QUERIES_T ADD(
  PRIMARY KEY ( TKIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.CQ_CCID ON bpcdb.CONTACT_QUERIES_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.UISETTINGS_T
(
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  UI_SETTINGS                        BLOB                 NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.UISETTINGS_T ADD(
  PRIMARY KEY ( TKIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.UIS_CCID ON bpcdb.UISETTINGS_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.REPLY_HANDLER_T
(
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  REPLY_HANDLER                      BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.REPLY_HANDLER_T ADD(
  PRIMARY KEY ( TKIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.RH_CCID ON bpcdb.REPLY_HANDLER_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_TIMER_T
(
  OID                                RAW(16)              NOT NULL ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  SCHEDULER_ID                       VARCHAR2(254)        NOT NULL ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_TIMER_T ADD(
  PRIMARY KEY ( OID, KIND )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.TASK_INST_CPROP_T
(
  TKIID                              RAW(16)              NOT NULL ,
  NAME                               VARCHAR2(220)        NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DATA_TYPE                          VARCHAR2(254)                 ,
  STRING_VALUE                       VARCHAR2(254)                 ,
  DATA                               BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_INST_CPROP_T ADD(
  PRIMARY KEY ( TKIID, NAME )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TICP_CCID ON bpcdb.TASK_INST_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_INST_LDESC_T
(
  TKIID                              RAW(16)              NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DISPLAY_NAME                       VARCHAR2(64)                  ,
  DESCRIPTION                        VARCHAR2(254)                 ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_INST_LDESC_T ADD(
  PRIMARY KEY ( TKIID, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TILD_CCID ON bpcdb.TASK_INST_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TIDOCUMENTATION_T
(
  TKIID                              RAW(16)              NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  DOCUMENTATION                      CLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TIDOCUMENTATION_T ADD(
  PRIMARY KEY ( TKIID, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TIDOC_CCID ON bpcdb.TIDOCUMENTATION_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.ITASK_MESSAGE_DEFINITION_T
(
  TMTID                              RAW(16)              NOT NULL ,
  TKIID                              RAW(16)                       ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  FAULT_NAME                         VARCHAR2(254)                 ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  MESSAGE_TYPE_NS                    VARCHAR2(220)        NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR2(220)        NOT NULL ,
  MESSAGE_DEFINITION                 BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.ITASK_MESSAGE_DEFINITION_T ADD(
  PRIMARY KEY ( TMTID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.ITMD_IDKINSTYPE ON bpcdb.ITASK_MESSAGE_DEFINITION_T
(   
  TKIID, MESSAGE_TYPE_NS, MESSAGE_TYPE_NAME, KIND
) LOGGING;

CREATE INDEX bpcdb.ITMD_TKIIDKINDFN ON bpcdb.ITASK_MESSAGE_DEFINITION_T
(   
  TKIID, KIND, FAULT_NAME
) LOGGING;

CREATE INDEX bpcdb.ITMD_CCID ON bpcdb.ITASK_MESSAGE_DEFINITION_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_MESSAGE_INSTANCE_T
(
  TMIID                              RAW(16)              NOT NULL ,
  TMTID                              RAW(16)                       ,
  TKIID                              RAW(16)              NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  FAULT_NAME                         VARCHAR2(254)                 ,
  KIND                               NUMBER(10,0)         NOT NULL ,
  MESSAGE_TYPE_NS                    VARCHAR2(220)        NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR2(220)        NOT NULL ,
  DATA                               BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_MESSAGE_INSTANCE_T ADD(
  PRIMARY KEY ( TMIID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.TMI_TI_K ON bpcdb.TASK_MESSAGE_INSTANCE_T
(   
  TKIID, KIND
) LOGGING;

CREATE INDEX bpcdb.TMI_TMTID ON bpcdb.TASK_MESSAGE_INSTANCE_T
(   
  TMTID
) LOGGING;

CREATE INDEX bpcdb.TMI_CCID ON bpcdb.TASK_MESSAGE_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;

CREATE TABLE bpcdb.TASK_AUDIT_LOG_T
(
  ALID                               RAW(16)              NOT NULL ,
  AUDIT_EVENT                        NUMBER(10,0)         NOT NULL ,
  TKIID                              RAW(16)                       ,
  TKTID                              RAW(16)                       ,
  ESIID                              RAW(16)                       ,
  ESTID                              RAW(16)                       ,
  TOP_TKIID                          RAW(16)                       ,
  FOLLOW_ON_TKIID                    RAW(16)                       ,
  PARENT_TKIID                       RAW(16)                       ,
  PARENT_CONTEXT_ID                  RAW(16)                       ,
  CONTAINMENT_CONTEXT_ID             RAW(16)                       ,
  WI_REASON                          NUMBER(10,0)                  ,
  NAME                               VARCHAR2(254)                 ,
  NAMESPACE                          VARCHAR2(254)                 ,
  VALID_FROM_UTC                     TIMESTAMP                     ,
  EVENT_TIME_UTC                     TIMESTAMP                     ,
  PARENT_TASK_NAME                   VARCHAR2(254)                 ,
  PARENT_TASK_NAMESPACE              VARCHAR2(254)                 ,
  TASK_KIND                          NUMBER(10,0)                  ,
  TASK_STATE                         NUMBER(10,0)                  ,
  FAULT_TYPE_NAME                    VARCHAR2(220)                 ,
  FAULT_NAMESPACE                    VARCHAR2(220)                 ,
  FAULT_NAME                         VARCHAR2(220)                 ,
  NEW_USER                           VARCHAR2(128)                 ,
  OLD_USER                           VARCHAR2(128)                 ,
  PRINCIPAL                          VARCHAR2(128)                 ,
  USERS                              CLOB                          ,
  DESCRIPTION                        CLOB                          ,
  MESSAGE_DATA                       BLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.TASK_AUDIT_LOG_T ADD(
  PRIMARY KEY ( ALID )
  USING INDEX TABLESPACE INDEXTS
);

CREATE TABLE bpcdb.IMAIL_T
(
  OBJECT_ID                          RAW(16)              NOT NULL ,
  FROM_STATE                         NUMBER(10,0)         NOT NULL ,
  TO_STATE                           NUMBER(10,0)         NOT NULL ,
  LOCALE                             VARCHAR2(32)         NOT NULL ,
  CONTAINMENT_CONTEXT_ID             RAW(16)              NOT NULL ,
  SUBJECT                            VARCHAR2(254)        NOT NULL ,
  URI                                VARCHAR2(254)                 ,
  BODY_TEXT                          CLOB                          ,
  VERSION_ID                         NUMBER(5,0)          NOT NULL 
) LOGGING;

ALTER TABLE bpcdb.IMAIL_T ADD(
  PRIMARY KEY ( OBJECT_ID, FROM_STATE, TO_STATE, LOCALE )
  USING INDEX TABLESPACE INDEXTS
);

CREATE INDEX bpcdb.IMN_CTX ON bpcdb.IMAIL_T
(   
  CONTAINMENT_CONTEXT_ID
) LOGGING;
-- set schema version to: 612
INSERT INTO bpcdb.SCHEMA_VERSION (SCHEMA_VERSION, DATA_MIGRATION) VALUES( 612, 0 );


-- View: ProcessTemplate
CREATE VIEW bpcdb.PROCESS_TEMPLATE(PTID, NAME, DISPLAY_NAME, VALID_FROM, TARGET_NAMESPACE, APPLICATION_NAME, VERSION, CREATED, STATE, EXECUTION_MODE, DESCRIPTION, CAN_RUN_SYNC, CAN_RUN_INTERRUP, COMP_SPHERE, CONTINUE_ON_ERROR ) AS
 SELECT bpcdb.PROCESS_TEMPLATE_B_T.PTID, bpcdb.PROCESS_TEMPLATE_B_T.NAME, bpcdb.PROCESS_TEMPLATE_B_T.DISPLAY_NAME, bpcdb.PROCESS_TEMPLATE_B_T.VALID_FROM, bpcdb.PROCESS_TEMPLATE_B_T.TARGET_NAMESPACE, bpcdb.PROCESS_TEMPLATE_B_T.APPLICATION_NAME, bpcdb.PROCESS_TEMPLATE_B_T.VERSION, bpcdb.PROCESS_TEMPLATE_B_T.CREATED, bpcdb.PROCESS_TEMPLATE_B_T.STATE, bpcdb.PROCESS_TEMPLATE_B_T.EXECUTION_MODE, bpcdb.PROCESS_TEMPLATE_B_T.DESCRIPTION, bpcdb.PROCESS_TEMPLATE_B_T.CAN_CALL, bpcdb.PROCESS_TEMPLATE_B_T.CAN_INITIATE, bpcdb.PROCESS_TEMPLATE_B_T.COMPENSATION_SPHERE, bpcdb.PROCESS_TEMPLATE_B_T.CONTINUE_ON_ERROR
 FROM bpcdb.PROCESS_TEMPLATE_B_T;

-- View: ProcessTemplAttr
CREATE VIEW bpcdb.PROCESS_TEMPL_ATTR(PTID, NAME, VALUE ) AS
 SELECT bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T.PTID, bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T.ATTR_KEY, bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T.VALUE
 FROM bpcdb.PROCESS_TEMPLATE_ATTRIBUTE_B_T;

-- View: ProcessInstance
CREATE VIEW bpcdb.PROCESS_INSTANCE(PTID, PIID, NAME, STATE, CREATED, STARTED, COMPLETED, PARENT_NAME, TOP_LEVEL_NAME, PARENT_PIID, TOP_LEVEL_PIID, STARTER, DESCRIPTION, TEMPLATE_NAME, TEMPLATE_DESCR, RESUMES, CONTINUE_ON_ERROR ) AS
 SELECT bpcdb.PROCESS_INSTANCE_B_T.PTID, bpcdb.PROCESS_INSTANCE_B_T.PIID, bpcdb.PROCESS_INSTANCE_B_T.NAME, bpcdb.PROCESS_INSTANCE_B_T.STATE, bpcdb.PROCESS_INSTANCE_B_T.CREATED, bpcdb.PROCESS_INSTANCE_B_T.STARTED, bpcdb.PROCESS_INSTANCE_B_T.COMPLETED, bpcdb.PROCESS_INSTANCE_B_T.PARENT_NAME, bpcdb.PROCESS_INSTANCE_B_T.TOP_LEVEL_NAME, bpcdb.PROCESS_INSTANCE_B_T.PARENT_PIID, bpcdb.PROCESS_INSTANCE_B_T.TOP_LEVEL_PIID, bpcdb.PROCESS_INSTANCE_B_T.STARTER, bpcdb.PROCESS_INSTANCE_B_T.DESCRIPTION, bpcdb.PROCESS_TEMPLATE_B_T.NAME, bpcdb.PROCESS_TEMPLATE_B_T.DESCRIPTION, bpcdb.PROCESS_INSTANCE_B_T.RESUMES, bpcdb.PROCESS_TEMPLATE_B_T.CONTINUE_ON_ERROR
 FROM bpcdb.PROCESS_INSTANCE_B_T, bpcdb.PROCESS_TEMPLATE_B_T
 WHERE bpcdb.PROCESS_INSTANCE_B_T.PTID = bpcdb.PROCESS_TEMPLATE_B_T.PTID;

-- View: ProcessAttribute
CREATE VIEW bpcdb.PROCESS_ATTRIBUTE(PIID, NAME, VALUE ) AS
 SELECT bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T.PIID, bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T.ATTR_KEY, bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T.VALUE
 FROM bpcdb.PROCESS_INSTANCE_ATTRIBUTE_T;

-- View: Activity
CREATE VIEW bpcdb.ACTIVITY(PIID, AIID, PTID, ATID, SIID, STID, EHIID, ENCLOSING_FEIID, KIND, COMPLETED, ACTIVATED, FIRST_ACTIVATED, STARTED, STATE, STOP_REASON, OWNER, DESCRIPTION, EXPIRES, TEMPLATE_NAME, TEMPLATE_DESCR, BUSINESS_RELEVANCE, SKIP_REQUESTED, CONTINUE_ON_ERROR ) AS
 SELECT bpcdb.ACTIVITY_INSTANCE_B_T.PIID, bpcdb.ACTIVITY_INSTANCE_B_T.AIID, bpcdb.ACTIVITY_INSTANCE_B_T.PTID, bpcdb.ACTIVITY_INSTANCE_B_T.ATID, bpcdb.ACTIVITY_INSTANCE_B_T.SIID, bpcdb.ACTIVITY_TEMPLATE_B_T.PARENT_STID, bpcdb.ACTIVITY_INSTANCE_B_T.EHIID, bpcdb.ACTIVITY_INSTANCE_B_T.ENCLOSING_FEIID, bpcdb.ACTIVITY_TEMPLATE_B_T.KIND, bpcdb.ACTIVITY_INSTANCE_B_T.FINISHED, bpcdb.ACTIVITY_INSTANCE_B_T.ACTIVATED, bpcdb.ACTIVITY_INSTANCE_B_T.FIRST_ACTIVATED, bpcdb.ACTIVITY_INSTANCE_B_T.STARTED, bpcdb.ACTIVITY_INSTANCE_B_T.STATE, bpcdb.ACTIVITY_INSTANCE_B_T.STOP_REASON, bpcdb.ACTIVITY_INSTANCE_B_T.OWNER, bpcdb.ACTIVITY_INSTANCE_B_T.DESCRIPTION, bpcdb.ACTIVITY_INSTANCE_B_T.EXPIRES, bpcdb.ACTIVITY_TEMPLATE_B_T.NAME, bpcdb.ACTIVITY_TEMPLATE_B_T.DESCRIPTION, bpcdb.ACTIVITY_TEMPLATE_B_T.BUSINESS_RELEVANCE, bpcdb.ACTIVITY_INSTANCE_B_T.SKIP_REQUESTED, bpcdb.ACTIVITY_INSTANCE_B_T.CONTINUE_ON_ERROR
 FROM bpcdb.ACTIVITY_INSTANCE_B_T, bpcdb.ACTIVITY_TEMPLATE_B_T
 WHERE bpcdb.ACTIVITY_INSTANCE_B_T.ATID = bpcdb.ACTIVITY_TEMPLATE_B_T.ATID;

-- View: ActivityAttribute
CREATE VIEW bpcdb.ACTIVITY_ATTRIBUTE(AIID, NAME, VALUE ) AS
 SELECT bpcdb.ACTIVITY_INSTANCE_ATTR_B_T.AIID, bpcdb.ACTIVITY_INSTANCE_ATTR_B_T.ATTR_KEY, bpcdb.ACTIVITY_INSTANCE_ATTR_B_T.ATTR_VALUE
 FROM bpcdb.ACTIVITY_INSTANCE_ATTR_B_T;

-- View: Event
CREATE VIEW bpcdb.EVENT(EIID, AIID, PIID, EHTID, SIID, NAME ) AS
 SELECT bpcdb.EVENT_INSTANCE_B_T.EIID, bpcdb.EVENT_INSTANCE_B_T.AIID, bpcdb.EVENT_INSTANCE_B_T.PIID, bpcdb.EVENT_INSTANCE_B_T.EHTID, bpcdb.EVENT_INSTANCE_B_T.SIID, bpcdb.SERVICE_TEMPLATE_B_T.NAME
 FROM bpcdb.EVENT_INSTANCE_B_T, bpcdb.SERVICE_TEMPLATE_B_T
 WHERE bpcdb.EVENT_INSTANCE_B_T.STATE = 2 AND bpcdb.EVENT_INSTANCE_B_T.VTID = bpcdb.SERVICE_TEMPLATE_B_T.VTID;

-- View: WorkItem
CREATE VIEW bpcdb.WORK_ITEM(WIID, OWNER_ID, GROUP_NAME, EVERYBODY, OBJECT_TYPE, OBJECT_ID, ASSOC_OBJECT_TYPE, ASSOC_OID, REASON, CREATION_TIME, QIID, KIND ) AS
 SELECT bpcdb.WORK_ITEM_T.WIID, bpcdb.WORK_ITEM_T.OWNER_ID, bpcdb.WORK_ITEM_T.GROUP_NAME, bpcdb.WORK_ITEM_T.EVERYBODY, bpcdb.WORK_ITEM_T.OBJECT_TYPE, bpcdb.WORK_ITEM_T.OBJECT_ID, bpcdb.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, bpcdb.WORK_ITEM_T.ASSOCIATED_OID, bpcdb.WORK_ITEM_T.REASON, bpcdb.WORK_ITEM_T.CREATION_TIME, bpcdb.WORK_ITEM_T.QIID, bpcdb.WORK_ITEM_T.KIND
 FROM bpcdb.WORK_ITEM_T
 WHERE bpcdb.WORK_ITEM_T.QIID IS NULL OR bpcdb.WORK_ITEM_T.EVERYBODY = 1
 UNION ALL SELECT bpcdb.WORK_ITEM_T.WIID, bpcdb.WORK_ITEM_T.OWNER_ID, bpcdb.WORK_ITEM_T.GROUP_NAME, bpcdb.WORK_ITEM_T.EVERYBODY, bpcdb.WI_ASSOC_OID_T.OBJECT_TYPE, bpcdb.WI_ASSOC_OID_T.OBJECT_ID, bpcdb.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, bpcdb.WORK_ITEM_T.ASSOCIATED_OID, bpcdb.WI_ASSOC_OID_T.REASON, bpcdb.WORK_ITEM_T.CREATION_TIME, bpcdb.WORK_ITEM_T.QIID, bpcdb.WORK_ITEM_T.KIND
 FROM bpcdb.WORK_ITEM_T, bpcdb.WI_ASSOC_OID_T
 WHERE bpcdb.WORK_ITEM_T.WIID = bpcdb.WI_ASSOC_OID_T.WIID AND (bpcdb.WORK_ITEM_T.QIID IS NULL OR bpcdb.WORK_ITEM_T.EVERYBODY = 1)
 UNION ALL SELECT bpcdb.WORK_ITEM_T.WIID, bpcdb.RETRIEVED_USER_T.OWNER_ID, bpcdb.WORK_ITEM_T.GROUP_NAME, bpcdb.WORK_ITEM_T.EVERYBODY, bpcdb.WORK_ITEM_T.OBJECT_TYPE, bpcdb.WORK_ITEM_T.OBJECT_ID, bpcdb.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, bpcdb.WORK_ITEM_T.ASSOCIATED_OID, bpcdb.WORK_ITEM_T.REASON, bpcdb.WORK_ITEM_T.CREATION_TIME, bpcdb.WORK_ITEM_T.QIID, bpcdb.WORK_ITEM_T.KIND
 FROM bpcdb.WORK_ITEM_T, bpcdb.RETRIEVED_USER_T
 WHERE bpcdb.WORK_ITEM_T.QIID = bpcdb.RETRIEVED_USER_T.QIID
 UNION ALL SELECT bpcdb.WORK_ITEM_T.WIID, bpcdb.RETRIEVED_USER_T.OWNER_ID, bpcdb.WORK_ITEM_T.GROUP_NAME, bpcdb.WORK_ITEM_T.EVERYBODY, bpcdb.WI_ASSOC_OID_T.OBJECT_TYPE, bpcdb.WI_ASSOC_OID_T.OBJECT_ID, bpcdb.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, bpcdb.WORK_ITEM_T.ASSOCIATED_OID, bpcdb.WI_ASSOC_OID_T.REASON, bpcdb.WORK_ITEM_T.CREATION_TIME, bpcdb.WORK_ITEM_T.QIID, bpcdb.WORK_ITEM_T.KIND
 FROM bpcdb.WORK_ITEM_T, bpcdb.RETRIEVED_USER_T, bpcdb.WI_ASSOC_OID_T
 WHERE bpcdb.WORK_ITEM_T.QIID = bpcdb.RETRIEVED_USER_T.QIID AND bpcdb.WORK_ITEM_T.WIID = bpcdb.WI_ASSOC_OID_T.WIID;

-- View: ActivityService
CREATE VIEW bpcdb.ACTIVITY_SERVICE(EIID, AIID, PIID, VTID, PORT_TYPE, NAME_SPACE_URI, OPERATION ) AS
 SELECT bpcdb.EVENT_INSTANCE_B_T.EIID, bpcdb.EVENT_INSTANCE_B_T.AIID, bpcdb.EVENT_INSTANCE_B_T.PIID, bpcdb.EVENT_INSTANCE_B_T.VTID, bpcdb.SERVICE_TEMPLATE_B_T.PORT_TYPE_NAME,bpcdb.URI_TEMPLATE_B_T.URI, bpcdb.SERVICE_TEMPLATE_B_T.OPERATION_NAME
 FROM bpcdb.EVENT_INSTANCE_B_T, bpcdb.SERVICE_TEMPLATE_B_T, bpcdb.URI_TEMPLATE_B_T
 WHERE bpcdb.EVENT_INSTANCE_B_T.STATE = 2 AND bpcdb.EVENT_INSTANCE_B_T.VTID = bpcdb.SERVICE_TEMPLATE_B_T.VTID AND bpcdb.SERVICE_TEMPLATE_B_T.PORT_TYPE_UTID = bpcdb.URI_TEMPLATE_B_T.UTID;

-- View: QueryProperty
CREATE VIEW bpcdb.QUERY_PROPERTY(PIID, VARIABLE_NAME, NAME, NAMESPACE, GENERIC_VALUE, STRING_VALUE, NUMBER_VALUE, DECIMAL_VALUE, TIMESTAMP_VALUE ) AS
 SELECT bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.PIID, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.VARIABLE_NAME, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.PROPERTY_NAME, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.PROPERTY_NAMESPACE, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.GENERIC_VALUE, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.STRING_VALUE, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.NUMBER_VALUE, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.DECIMAL_VALUE, bpcdb.QUERYABLE_VARIABLE_INSTANCE_T.TIMESTAMP_VALUE
 FROM bpcdb.QUERYABLE_VARIABLE_INSTANCE_T;

-- View: QueryPropTempl
CREATE VIEW bpcdb.QUERY_PROP_TEMPL(PTID, NAME, PROPERTY_NAME, URI, QUERY_TYPE, JAVA_TYPE ) AS
 SELECT bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T.PTID, bpcdb.VARIABLE_TEMPLATE_B_T.NAME, bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T.PROPERTY_NAME, bpcdb.URI_TEMPLATE_B_T.URI, bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T.QUERY_TYPE, bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T.JAVA_TYPE
 FROM bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T, bpcdb.VARIABLE_TEMPLATE_B_T, bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T, bpcdb.URI_TEMPLATE_B_T
 WHERE bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T.CTID = bpcdb.VARIABLE_TEMPLATE_B_T.CTID AND bpcdb.QUERYABLE_VARIABLE_TEMPLATE_T.PAID = bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T.PAID AND bpcdb.PROPERTY_ALIAS_TEMPLATE_B_T.PROPERTY_UTID = bpcdb.URI_TEMPLATE_B_T.UTID;

-- View: AuditLog
CREATE VIEW bpcdb.AUDIT_LOG(ALID, EVENT_TIME, EVENT_TIME_UTC, AUDIT_EVENT, PTID, PIID, AIID, SIID, SCOPE_NAME, PROCESS_TEMPL_NAME, PROCESS_INST_NAME, TOP_LEVEL_PI_NAME, TOP_LEVEL_PIID, PARENT_PI_NAME, PARENT_PIID, VALID_FROM, VALID_FROM_UTC, ACTIVITY_NAME, ACTIVITY_KIND, ACTIVITY_STATE, CONTROL_LINK_NAME, IMPL_NAME, PRINCIPAL, TERMINAL_NAME, VARIABLE_DATA, EXCEPTION_TEXT, DESCRIPTION, CORR_SET_INFO, USER_NAME, ATID, ADDITIONAL_INFO, OBJECT_META_TYPE ) AS
 SELECT bpcdb.AUDIT_LOG_T.ALID,bpcdb.AUDIT_LOG_T.EVENT_TIME,bpcdb.AUDIT_LOG_T.EVENT_TIME_UTC,bpcdb.AUDIT_LOG_T.AUDIT_EVENT,bpcdb.AUDIT_LOG_T.PTID,bpcdb.AUDIT_LOG_T.PIID,bpcdb.AUDIT_LOG_T.AIID,bpcdb.AUDIT_LOG_T.SIID,bpcdb.AUDIT_LOG_T.VARIABLE_NAME,bpcdb.AUDIT_LOG_T.PROCESS_TEMPL_NAME, bpcdb.AUDIT_LOG_T.PROCESS_INST_NAME,bpcdb.AUDIT_LOG_T.TOP_LEVEL_PI_NAME,bpcdb.AUDIT_LOG_T.TOP_LEVEL_PIID,bpcdb.AUDIT_LOG_T.PARENT_PI_NAME,bpcdb.AUDIT_LOG_T.PARENT_PIID,bpcdb.AUDIT_LOG_T.VALID_FROM,bpcdb.AUDIT_LOG_T.VALID_FROM_UTC, bpcdb.AUDIT_LOG_T.ACTIVITY_NAME,bpcdb.AUDIT_LOG_T.ACTIVITY_KIND,bpcdb.AUDIT_LOG_T.ACTIVITY_STATE,bpcdb.AUDIT_LOG_T.CONTROL_LINK_NAME,bpcdb.AUDIT_LOG_T.IMPL_NAME,bpcdb.AUDIT_LOG_T.PRINCIPAL, bpcdb.AUDIT_LOG_T.TERMINAL_NAME,bpcdb.AUDIT_LOG_T.VARIABLE_DATA,bpcdb.AUDIT_LOG_T.EXCEPTION_TEXT,bpcdb.AUDIT_LOG_T.DESCRIPTION,bpcdb.AUDIT_LOG_T.CORR_SET_INFO,bpcdb.AUDIT_LOG_T.USER_NAME, bpcdb.AUDIT_LOG_T.ATID, bpcdb.AUDIT_LOG_T.ADDITIONAL_INFO, bpcdb.AUDIT_LOG_T.OBJECT_META_TYPE
 FROM bpcdb.AUDIT_LOG_T;

-- View: AuditLogB
CREATE VIEW bpcdb.AUDIT_LOG_B(ALID, EVENT_TIME, EVENT_TIME_UTC, AUDIT_EVENT, PTID, PIID, AIID, SIID, VARIABLE_NAME, PROCESS_TEMPL_NAME, TOP_LEVEL_PIID, PARENT_PIID, VALID_FROM, VALID_FROM_UTC, ATID, ACTIVITY_NAME, ACTIVITY_KIND, ACTIVITY_STATE, CONTROL_LINK_NAME, PRINCIPAL, VARIABLE_DATA, EXCEPTION_TEXT, DESCRIPTION, CORR_SET_INFO, USER_NAME, ADDITIONAL_INFO ) AS
 SELECT bpcdb.AUDIT_LOG_T.ALID,bpcdb.AUDIT_LOG_T.EVENT_TIME,bpcdb.AUDIT_LOG_T.EVENT_TIME_UTC,bpcdb.AUDIT_LOG_T.AUDIT_EVENT,bpcdb.AUDIT_LOG_T.PTID,bpcdb.AUDIT_LOG_T.PIID,bpcdb.AUDIT_LOG_T.AIID,bpcdb.AUDIT_LOG_T.SIID,bpcdb.AUDIT_LOG_T.VARIABLE_NAME,bpcdb.AUDIT_LOG_T.PROCESS_TEMPL_NAME, bpcdb.AUDIT_LOG_T.TOP_LEVEL_PIID,bpcdb.AUDIT_LOG_T.PARENT_PIID,bpcdb.AUDIT_LOG_T.VALID_FROM,bpcdb.AUDIT_LOG_T.VALID_FROM_UTC,bpcdb.AUDIT_LOG_T.ATID, bpcdb.AUDIT_LOG_T.ACTIVITY_NAME,bpcdb.AUDIT_LOG_T.ACTIVITY_KIND,bpcdb.AUDIT_LOG_T.ACTIVITY_STATE,bpcdb.AUDIT_LOG_T.CONTROL_LINK_NAME,bpcdb.AUDIT_LOG_T.PRINCIPAL, bpcdb.AUDIT_LOG_T.VARIABLE_DATA,bpcdb.AUDIT_LOG_T.EXCEPTION_TEXT,bpcdb.AUDIT_LOG_T.DESCRIPTION,bpcdb.AUDIT_LOG_T.CORR_SET_INFO,bpcdb.AUDIT_LOG_T.USER_NAME, bpcdb.AUDIT_LOG_T.ADDITIONAL_INFO
 FROM bpcdb.AUDIT_LOG_T
 WHERE bpcdb.AUDIT_LOG_T.OBJECT_META_TYPE = 1;

-- View: ApplicationComp
CREATE VIEW bpcdb.APPLICATION_COMP(ACOID, BUSINESS_RELEVANCE, NAME, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON ) AS
 SELECT bpcdb.APPLICATION_COMPONENT_T.ACOID, bpcdb.APPLICATION_COMPONENT_T.BUSINESS_RELEVANCE, bpcdb.APPLICATION_COMPONENT_T.NAME, bpcdb.APPLICATION_COMPONENT_T.SUPPORTS_AUTO_CLAIM, bpcdb.APPLICATION_COMPONENT_T.SUPPORTS_CLAIM_SUSPENDED, bpcdb.APPLICATION_COMPONENT_T.SUPPORTS_DELEGATION, bpcdb.APPLICATION_COMPONENT_T.SUPPORTS_SUB_TASK, bpcdb.APPLICATION_COMPONENT_T.SUPPORTS_FOLLOW_ON_TASK
 FROM bpcdb.APPLICATION_COMPONENT_T;

-- View: Task
CREATE VIEW bpcdb.TASK(TKIID, ACTIVATED, APPLIC_DEFAULTS_ID, APPLIC_NAME, BUSINESS_RELEVANCE, COMPLETED, CONTAINMENT_CTX_ID, CTX_AUTHORIZATION, DUE, EXPIRES, FIRST_ACTIVATED, FOLLOW_ON_TKIID, IS_AD_HOC, IS_ESCALATED, IS_INLINE, IS_WAIT_FOR_SUB_TK, KIND, LAST_MODIFIED, LAST_STATE_CHANGE, NAME, NAME_SPACE, ORIGINATOR, OWNER, PARENT_CONTEXT_ID, PRIORITY, STARTED, STARTER, STATE, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON, HIERARCHY_POSITION, SUSPENDED, TKTID, TOP_TKIID, TYPE, RESUMES ) AS
 SELECT bpcdb.TASK_INSTANCE_T.TKIID, bpcdb.TASK_INSTANCE_T.ACTIVATION_TIME, bpcdb.TASK_INSTANCE_T.APPLICATION_DEFAULTS_ID, bpcdb.TASK_INSTANCE_T.APPLICATION_NAME, bpcdb.TASK_INSTANCE_T.BUSINESS_RELEVANCE, bpcdb.TASK_INSTANCE_T.COMPLETION_TIME, bpcdb.TASK_INSTANCE_T.CONTAINMENT_CONTEXT_ID, bpcdb.TASK_INSTANCE_T.CONTEXT_AUTHORIZATION, bpcdb.TASK_INSTANCE_T.DUE_TIME, bpcdb.TASK_INSTANCE_T.EXPIRATION_TIME, bpcdb.TASK_INSTANCE_T.FIRST_ACTIVATION_TIME, bpcdb.TASK_INSTANCE_T.FOLLOW_ON_TKIID, bpcdb.TASK_INSTANCE_T.IS_AD_HOC, bpcdb.TASK_INSTANCE_T.IS_ESCALATED, bpcdb.TASK_INSTANCE_T.IS_INLINE, bpcdb.TASK_INSTANCE_T.IS_WAITING_FOR_SUBTASK, bpcdb.TASK_INSTANCE_T.KIND, bpcdb.TASK_INSTANCE_T.LAST_MODIFICATION_TIME, bpcdb.TASK_INSTANCE_T.LAST_STATE_CHANGE_TIME, bpcdb.TASK_INSTANCE_T.NAME, bpcdb.TASK_INSTANCE_T.NAMESPACE, bpcdb.TASK_INSTANCE_T.ORIGINATOR, bpcdb.TASK_INSTANCE_T.OWNER, bpcdb.TASK_INSTANCE_T.PARENT_CONTEXT_ID, bpcdb.TASK_INSTANCE_T.PRIORITY, bpcdb.TASK_INSTANCE_T.START_TIME, bpcdb.TASK_INSTANCE_T.STARTER, bpcdb.TASK_INSTANCE_T.STATE, bpcdb.TASK_INSTANCE_T.SUPPORTS_AUTO_CLAIM, bpcdb.TASK_INSTANCE_T.SUPPORTS_CLAIM_SUSPENDED, bpcdb.TASK_INSTANCE_T.SUPPORTS_DELEGATION, bpcdb.TASK_INSTANCE_T.SUPPORTS_SUB_TASK, bpcdb.TASK_INSTANCE_T.SUPPORTS_FOLLOW_ON_TASK, bpcdb.TASK_INSTANCE_T.HIERARCHY_POSITION, bpcdb.TASK_INSTANCE_T.IS_SUSPENDED, bpcdb.TASK_INSTANCE_T.TKTID, bpcdb.TASK_INSTANCE_T.TOP_TKIID, bpcdb.TASK_INSTANCE_T.TYPE, bpcdb.TASK_INSTANCE_T.RESUMES
 FROM bpcdb.TASK_INSTANCE_T;

-- View: TaskTempl
CREATE VIEW bpcdb.TASK_TEMPL(TKTID, APPLIC_DEFAULTS_ID, APPLIC_NAME, BUSINESS_RELEVANCE, CONTAINMENT_CTX_ID, CTX_AUTHORIZATION, DEFINITION_NAME, DEFINITION_NS, IS_AD_HOC, IS_INLINE, KIND, NAME, NAMESPACE, PRIORITY, STATE, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON, TYPE, VALID_FROM ) AS
 SELECT bpcdb.TASK_TEMPLATE_T.TKTID, bpcdb.TASK_TEMPLATE_T.APPLICATION_DEFAULTS_ID, bpcdb.TASK_TEMPLATE_T.APPLICATION_NAME, bpcdb.TASK_TEMPLATE_T.BUSINESS_RELEVANCE, bpcdb.TASK_TEMPLATE_T.CONTAINMENT_CONTEXT_ID, bpcdb.TASK_TEMPLATE_T.CONTEXT_AUTHORIZATION, bpcdb.TASK_TEMPLATE_T.DEFINITION_NAME, bpcdb.TASK_TEMPLATE_T.TARGET_NAMESPACE, bpcdb.TASK_TEMPLATE_T.IS_AD_HOC, bpcdb.TASK_TEMPLATE_T.IS_INLINE, bpcdb.TASK_TEMPLATE_T.KIND, bpcdb.TASK_TEMPLATE_T.NAME, bpcdb.TASK_TEMPLATE_T.NAMESPACE, bpcdb.TASK_TEMPLATE_T.PRIORITY, bpcdb.TASK_TEMPLATE_T.STATE, bpcdb.TASK_TEMPLATE_T.SUPPORTS_AUTO_CLAIM, bpcdb.TASK_TEMPLATE_T.SUPPORTS_CLAIM_SUSPENDED, bpcdb.TASK_TEMPLATE_T.SUPPORTS_DELEGATION, bpcdb.TASK_TEMPLATE_T.SUPPORTS_SUB_TASK, bpcdb.TASK_TEMPLATE_T.SUPPORTS_FOLLOW_ON_TASK, bpcdb.TASK_TEMPLATE_T.TYPE, bpcdb.TASK_TEMPLATE_T.VALID_FROM
 FROM bpcdb.TASK_TEMPLATE_T;

-- View: Escalation
CREATE VIEW bpcdb.ESCALATION(ESIID, ACTION, ACTIVATION_STATE, ACTIVATION_TIME, AT_LEAST_EXP_STATE, ESTID, FIRST_ESIID, INCREASE_PRIORITY, NAME, STATE, TKIID ) AS
 SELECT bpcdb.ESCALATION_INSTANCE_T.ESIID, bpcdb.ESCALATION_INSTANCE_T.ACTION, bpcdb.ESCALATION_INSTANCE_T.ACTIVATION_STATE, bpcdb.ESCALATION_INSTANCE_T.ACTIVATION_TIME, bpcdb.ESCALATION_INSTANCE_T.AT_LEAST_EXPECTED_STATE, bpcdb.ESCALATION_INSTANCE_T.ESTID, bpcdb.ESCALATION_INSTANCE_T.FIRST_ESIID, bpcdb.ESCALATION_INSTANCE_T.INCREASE_PRIORITY, bpcdb.ESCALATION_INSTANCE_T.NAME, bpcdb.ESCALATION_INSTANCE_T.STATE, bpcdb.ESCALATION_INSTANCE_T.TKIID
 FROM bpcdb.ESCALATION_INSTANCE_T;

-- View: EscTempl
CREATE VIEW bpcdb.ESC_TEMPL(ESTID, FIRST_ESTID, PREVIOUS_ESTID, TKTID, CONTAINMENT_CTX_ID, NAME, ACTIVATION_STATE, AT_LEAST_EXP_STATE, INCREASE_PRIORITY, ACTION ) AS
 SELECT bpcdb.ESCALATION_TEMPLATE_T.ESTID, bpcdb.ESCALATION_TEMPLATE_T.FIRST_ESTID, bpcdb.ESCALATION_TEMPLATE_T.PREVIOUS_ESTID, bpcdb.ESCALATION_TEMPLATE_T.TKTID, bpcdb.ESCALATION_TEMPLATE_T.CONTAINMENT_CONTEXT_ID, bpcdb.ESCALATION_TEMPLATE_T.NAME, bpcdb.ESCALATION_TEMPLATE_T.ACTIVATION_STATE, bpcdb.ESCALATION_TEMPLATE_T.AT_LEAST_EXPECTED_STATE, bpcdb.ESCALATION_TEMPLATE_T.INCREASE_PRIORITY, bpcdb.ESCALATION_TEMPLATE_T.ACTION
 FROM bpcdb.ESCALATION_TEMPLATE_T;

-- View: EscTemplDesc
CREATE VIEW bpcdb.ESC_TEMPL_DESC(ESTID, LOCALE, TKTID, DISPLAY_NAME, DESCRIPTION ) AS
 SELECT bpcdb.ESC_TEMPL_LDESC_T.ESTID, bpcdb.ESC_TEMPL_LDESC_T.LOCALE, bpcdb.ESC_TEMPL_LDESC_T.TKTID, bpcdb.ESC_TEMPL_LDESC_T.DISPLAY_NAME, bpcdb.ESC_TEMPL_LDESC_T.DESCRIPTION
 FROM bpcdb.ESC_TEMPL_LDESC_T;

-- View: TaskTemplCProp
CREATE VIEW bpcdb.TASK_TEMPL_CPROP(TKTID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT bpcdb.TASK_TEMPL_CPROP_T.TKTID, bpcdb.TASK_TEMPL_CPROP_T.NAME, bpcdb.TASK_TEMPL_CPROP_T.DATA_TYPE, bpcdb.TASK_TEMPL_CPROP_T.STRING_VALUE
 FROM bpcdb.TASK_TEMPL_CPROP_T;

-- View: EscTemplCProp
CREATE VIEW bpcdb.ESC_TEMPL_CPROP(ESTID, NAME, TKTID, DATA_TYPE, VALUE ) AS
 SELECT bpcdb.ESC_TEMPL_CPROP_T.ESTID, bpcdb.ESC_TEMPL_CPROP_T.NAME, bpcdb.ESC_TEMPL_CPROP_T.TKTID, bpcdb.ESC_TEMPL_CPROP_T.DATA_TYPE, bpcdb.ESC_TEMPL_CPROP_T.STRING_VALUE
 FROM bpcdb.ESC_TEMPL_CPROP_T;

-- View: TaskTemplDesc
CREATE VIEW bpcdb.TASK_TEMPL_DESC(TKTID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT bpcdb.TASK_TEMPL_LDESC_T.TKTID, bpcdb.TASK_TEMPL_LDESC_T.LOCALE, bpcdb.TASK_TEMPL_LDESC_T.DESCRIPTION, bpcdb.TASK_TEMPL_LDESC_T.DISPLAY_NAME
 FROM bpcdb.TASK_TEMPL_LDESC_T;

-- View: TaskCProp
CREATE VIEW bpcdb.TASK_CPROP(TKIID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT bpcdb.TASK_INST_CPROP_T.TKIID, bpcdb.TASK_INST_CPROP_T.NAME, bpcdb.TASK_INST_CPROP_T.DATA_TYPE, bpcdb.TASK_INST_CPROP_T.STRING_VALUE
 FROM bpcdb.TASK_INST_CPROP_T;

-- View: TaskDesc
CREATE VIEW bpcdb.TASK_DESC(TKIID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT bpcdb.TASK_INST_LDESC_T.TKIID, bpcdb.TASK_INST_LDESC_T.LOCALE, bpcdb.TASK_INST_LDESC_T.DESCRIPTION, bpcdb.TASK_INST_LDESC_T.DISPLAY_NAME
 FROM bpcdb.TASK_INST_LDESC_T;

-- View: EscalationCProp
CREATE VIEW bpcdb.ESCALATION_CPROP(ESIID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT bpcdb.ESC_INST_CPROP_T.ESIID, bpcdb.ESC_INST_CPROP_T.NAME, bpcdb.ESC_INST_CPROP_T.DATA_TYPE, bpcdb.ESC_INST_CPROP_T.STRING_VALUE
 FROM bpcdb.ESC_INST_CPROP_T;

-- View: EscalationDesc
CREATE VIEW bpcdb.ESCALATION_DESC(ESIID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT bpcdb.ESC_INST_LDESC_T.ESIID, bpcdb.ESC_INST_LDESC_T.LOCALE, bpcdb.ESC_INST_LDESC_T.DESCRIPTION, bpcdb.ESC_INST_LDESC_T.DISPLAY_NAME
 FROM bpcdb.ESC_INST_LDESC_T;

-- View: TaskAuditLog
CREATE VIEW bpcdb.TASK_AUDIT_LOG(ALID, AUDIT_EVENT, CONTAINMENT_CTX_ID, ESIID, ESTID, EVENT_TIME, FAULT_NAME, FAULT_TYPE_NAME, FAULT_NAME_SPACE, FOLLOW_ON_TKIID, NAME, NAMESPACE, NEW_USER, OLD_USER, PARENT_CONTEXT_ID, PARENT_TASK_NAME, PARENT_TASK_NAMESP, PARENT_TKIID, PRINCIPAL, TASK_KIND, TASK_STATE, TKIID, TKTID, TOP_TKIID, VAILD_FROM, WORK_ITEM_REASON, USERS, DESCRIPTION, MESSAGE_DATA ) AS
 SELECT bpcdb.TASK_AUDIT_LOG_T.ALID, bpcdb.TASK_AUDIT_LOG_T.AUDIT_EVENT, bpcdb.TASK_AUDIT_LOG_T.CONTAINMENT_CONTEXT_ID, bpcdb.TASK_AUDIT_LOG_T.ESIID, bpcdb.TASK_AUDIT_LOG_T.ESTID, bpcdb.TASK_AUDIT_LOG_T.EVENT_TIME_UTC, bpcdb.TASK_AUDIT_LOG_T.FAULT_NAME, bpcdb.TASK_AUDIT_LOG_T.FAULT_TYPE_NAME, bpcdb.TASK_AUDIT_LOG_T.FAULT_NAMESPACE, bpcdb.TASK_AUDIT_LOG_T.FOLLOW_ON_TKIID, bpcdb.TASK_AUDIT_LOG_T.NAME, bpcdb.TASK_AUDIT_LOG_T.NAMESPACE, bpcdb.TASK_AUDIT_LOG_T.NEW_USER, bpcdb.TASK_AUDIT_LOG_T.OLD_USER, bpcdb.TASK_AUDIT_LOG_T.PARENT_CONTEXT_ID, bpcdb.TASK_AUDIT_LOG_T.PARENT_TASK_NAME, bpcdb.TASK_AUDIT_LOG_T.PARENT_TASK_NAMESPACE, bpcdb.TASK_AUDIT_LOG_T.PARENT_TKIID, bpcdb.TASK_AUDIT_LOG_T.PRINCIPAL, bpcdb.TASK_AUDIT_LOG_T.TASK_KIND, bpcdb.TASK_AUDIT_LOG_T.TASK_STATE, bpcdb.TASK_AUDIT_LOG_T.TKIID, bpcdb.TASK_AUDIT_LOG_T.TKTID, bpcdb.TASK_AUDIT_LOG_T.TOP_TKIID, bpcdb.TASK_AUDIT_LOG_T.VALID_FROM_UTC, bpcdb.TASK_AUDIT_LOG_T.WI_REASON, bpcdb.TASK_AUDIT_LOG_T.USERS, bpcdb.TASK_AUDIT_LOG_T.DESCRIPTION, bpcdb.TASK_AUDIT_LOG_T.MESSAGE_DATA
 FROM bpcdb.TASK_AUDIT_LOG_T;


-- start import scheduler DDL: createSchemaOracle.ddl



CREATE TABLE bpcdb."SCHED_TASK"("TASKID" NUMBER(19) NOT NULL,
               "VERSION" VARCHAR2(5) NOT NULL,
               "ROW_VERSION" NUMBER(10) NOT NULL,
               "TASKTYPE" NUMBER(10) NOT NULL,
               "TASKSUSPENDED" NUMBER(1) NOT NULL,
               "CANCELLED" NUMBER(1) NOT NULL,
               "NEXTFIRETIME" NUMBER(19) NOT NULL,
               "STARTBYINTERVAL" VARCHAR2(254),
               "STARTBYTIME" NUMBER(19),
               "VALIDFROMTIME" NUMBER(19),
               "VALIDTOTIME" NUMBER(19),
               "REPEATINTERVAL" VARCHAR2(254),
               "MAXREPEATS" NUMBER(10) NOT NULL,
               "REPEATSLEFT" NUMBER(10) NOT NULL,
               "TASKINFO" BLOB,
               "NAME" VARCHAR2(254),
               "AUTOPURGE" NUMBER(10) NOT NULL,
               "FAILUREACTION" NUMBER(10),
               "MAXATTEMPTS" NUMBER(10),
               "QOS" NUMBER(10),
               "PARTITIONID" NUMBER(10),
               "OWNERTOKEN" VARCHAR2(200) NOT NULL,
               "CREATETIME" NUMBER(19) NOT NULL,
               PRIMARY KEY ("TASKID") );

CREATE INDEX bpcdb."SCHED_TASK_IDX1" ON bpcdb."SCHED_TASK" ("TASKID",
              "OWNERTOKEN") ;

CREATE INDEX bpcdb."SCHED_TASK_IDX2" ON bpcdb."SCHED_TASK" ("NEXTFIRETIME" ASC,
               "REPEATSLEFT",
               "PARTITIONID") ;

CREATE TABLE bpcdb."SCHED_TREG" ("REGKEY" VARCHAR2(254) NOT NULL ,
               "REGVALUE" VARCHAR2(254) ,
               PRIMARY KEY ( "REGKEY" ));

CREATE TABLE bpcdb."SCHED_LMGR" ("LEASENAME" VARCHAR2(254) NOT NULL,
               "LEASEOWNER" VARCHAR2(254),
               "LEASE_EXPIRE_TIME" NUMBER(19),
               "DISABLED" VARCHAR2(254),
               PRIMARY KEY ( "LEASENAME" ));

CREATE TABLE bpcdb."SCHED_LMPR" ("LEASENAME" VARCHAR2(254) NOT NULL,
               "NAME" VARCHAR2(254) NOT NULL,
               "VALUE" VARCHAR2(254) NOT NULL );

CREATE INDEX bpcdb."SCHED_LMPR_IDX1" ON bpcdb."SCHED_LMPR" ("LEASENAME",
               "NAME") ;

-- end import scheduler DDL: createSchemaOracle.ddl

QUIT
