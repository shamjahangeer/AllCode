--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
--
-- Scriptfile to create tablespaces for Oracle 9i and Oracle 10g
-- Start this script with SQL*Plus and pass the container location as a parameter
-- example: sqlplus scott/tiger@mydb @createTablespace.sql d:\mydb\ts
-- Or, replace parameters '&1' with the desired location and run the script
-- without any parameter
--

------------------------
-- Create tablespaces --
------------------------


CREATE TABLESPACE AUDITLOG
  DATAFILE '&1/AUDITLOG.dbf' SIZE 100M AUTOEXTEND ON NEXT 20M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE COMP
  DATAFILE '&1/COMP.dbf' SIZE 10M AUTOEXTEND ON NEXT 2M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE INDEXTS
  DATAFILE '&1/INDEXTS.dbf' SIZE 250M AUTOEXTEND ON NEXT 50M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE INSTANCE
  DATAFILE '&1/INSTANCE.dbf' SIZE 500M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE LOBTS
  DATAFILE '&1/LOBTS.dbf' SIZE 200M AUTOEXTEND ON NEXT 40M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE STAFFQRY
  DATAFILE '&1/STAFFQRY.dbf' SIZE 10M AUTOEXTEND ON NEXT 2M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE TEMPLATE
  DATAFILE '&1/TEMPLATE.dbf' SIZE 100M AUTOEXTEND ON NEXT 20M MAXSIZE UNLIMITED LOGGING;

CREATE TABLESPACE WORKITEM
  DATAFILE '&1/WORKITEM.dbf' SIZE 50M AUTOEXTEND ON NEXT 10M MAXSIZE UNLIMITED LOGGING;


-- start import scheduler DDL: createTablespaceOracle.ddl

CREATE TABLESPACE SCHEDTS DATAFILE '&1/SCHEDTS.dbf' SIZE 5M AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED;
-- end import scheduler DDL: createTablespaceOracle.ddl

QUIT
