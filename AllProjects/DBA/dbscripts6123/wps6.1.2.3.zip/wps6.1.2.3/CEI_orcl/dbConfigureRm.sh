#!/bin/sh
#
#  IBM Confidential OCO Source Material
#
#  5724-I63, 5724-H88, 5655-N02, 5733-W70 (C) COPYRIGHT International Business Machines Corp. 2004, 2005
#
#  The source code for this program is not published or otherwise divested
#  of its trade secrets, irrespective of what has been deposited with the
#  U.S. Copyright Office.
#
# ----------------------------------------------------------------------------

CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

cd $CURRENT_DIR

# expect inputs as SYS_USERID:SYS_PASSWORD:SID:ORACLE_HOME
read inputString
SYS_USERID=`echo "$inputString" | awk -F: '{print $1}'`
SYS_PASSWORD=`echo "$inputString" | awk -F: '{print $2}'`
SID_INPUT=`echo "$inputString" | awk -F: '{print $3}'`
ORACLE_HOME_INPUT=`echo "$inputString" | awk -F: '{print $4}'`
rc=0

# Generated SID
SID=SX09N5D7
# If SID is passed in then use it
if [ ! "$SID_INPUT" = "" ] ; then
   SID=$SID_INPUT
fi

# Generate oracle home
# If oracle home is passed in the use it
if [ ! "$ORACLE_HOME_INPUT" = "" ] ; then
   ORACLE_HOME=$ORACLE_HOME_INPUT
fi

# Check ORACLE_HOME
if [ ! -d $ORACLE_HOME ]; then
   echo "Oracle home $ORACLE_HOME does not exist. Exiting....."
   exit 1
fi

export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

ORACLE_ROLE=sysdba

#build connect satement
if [ "$SYS_PASSWORD" = "none" ] ; then
   CONNECT_STRING="/@$SID as $ORACLE_ROLE"
else
   CONNECT_STRING="$SYS_USERID/$SYS_PASSWORD@$SID as $ORACLE_ROLE"
fi
            
#Attempt to perform a test connection to Oracle to verify that the user id/password and SID work
            
result=`echo "quit;" | sqlplus -S "$CONNECT_STRING" < /dev/null`
            
#Were we able to connect? All Oracle error codes begin with ORA-
echo $result | grep "ORA-" > /dev/null
if [ $? -eq 0 ] ; then
   echo $result
   exit 1
fi
            
# Connection error
echo $result | grep "SP2-0306" > /dev/null
if [ $? -eq 0 ] ; then
   rc=1
   echo $result
fi
            
error=0

echo "sqlplus xxxxxx @$CURRENT_DIR/killsession.ora"
sqlplus -S /NOLOG <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING 
@killsession.ora ceidb
quit
EOF
rc=$?

if [ $rc -eq 0 ] ; then

echo "sqlplus xxxxxx @$CURRENT_DIR/tsdatafiles.ora"
sqlplus -S /NOLOG <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING 
spool filesToDelete.txt
@tsdatafiles.ora 
spool off
quit
EOF
rc=$?

if [ $rc -gt 0 ] || [ $rc -lt 0 ] ; then
   error=1
fi

result=`echo "sqlplus xxxxxx @$CURRENT_DIR/rm_tbl.ora"
sqlplus -S /NOLOG <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING 
@rm_tbl.ora 
quit
EOF`
rc=$?

echo $result | grep "ORA-" > /dev/null
if [ $? -eq 0 ] ; then
   echo "The Common Event Infrastructure does not exist"
   rc=40
   exit $rc   
fi

if [ $rc -gt 0 ] || [ $rc -lt 0 ] ; then
   error=1
fi

echo "sqlplus xxxxxx @$CURRENT_DIR/rm_tbl_catalog.ora"
sqlplus -S /NOLOG <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@rm_tbl_catalog.ora
quit
EOF
rc=$?

if [ $rc -gt 0 ] || [ $rc -lt 0 ] ; then
   error=1
fi
            
echo "sqlplus xxxxxx @$CURRENT_DIR/rm_ts.ora"
sqlplus -S /NOLOG <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@rm_ts.ora
quit
EOF
rc=$?

if [ $rc -gt 0 ] || [ $rc -lt 0 ] ; then
   error=1
fi

echo "sqlplus xxxxxx @$CURRENT_DIR/rm_ts_catalog.ora"
sqlplus -S /NOLOG <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@rm_ts_catalog.ora
quit
EOF
rc=$?
  
if [ $rc -gt 0 ] || [ $rc -lt 0 ] ; then
   error=1
fi

echo "sqlplus xxxxxx @$CURRENT_DIR/rm_stored_procedure.ora"
sqlplus -S /NOLOG <<EOF
connect $CONNECT_STRING
@rm_stored_procedure.ora
quit
EOF
rc=$?

if [ $rc -gt 0 ] || [ $rc -lt 0 ] ; then
   error=1
fi

echo "sqlplus xxxxxx @$CURRENT_DIR/rm_security.ora"
sqlplus -S /NOLOG <<EOF
connect $CONNECT_STRING
@rm_security.ora
quit
EOF
rc=$?

else
   error=1
   echo "The Common Event Infrastructure database is active."
   echo "Stop the WebSphere Application Server and the script again."
   exit $error
fi

if [ $error -eq 0 ] ; then
   echo "The Common Event Infrastructure database is removed successfully."
   echo "The following table space files can be manually deleted to save disk space:"
   cat $CURRENT_DIR/filesToDelete.txt
   rm -f $CURRENT_DIR/filesToDelete.txt
else
   echo "The Common Event Infrastructure database is removed with errors."
fi
                    
exit $error
