#!/bin/sh
#
#
#  IBM Confidential OCO Source Material
#
#  5724-I63, 5724-H88, 5655-N02, 5733-W70 (C) COPYRIGHT International Business Machines Corp. 2005
#
#  The source code for this program is not published or otherwise divested
#  of its trade secrets, irrespective of what has been deposited with the
#  U.S. Copyright Office.
#
#------------------------------------------------------------------------------

# Find the current directory
CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

cd $CURRENT_DIR

# expect inputs as USER_PASSWORD:SYS_USERID:SYS_PASSWORD:SID:ORACLE_HOME
read inputString
USER_PASSWORD=`echo "$inputString" | awk -F: '{print $1}'`
SYS_USERID=`echo "$inputString" | awk -F: '{print $2}'`
SYS_PASSWORD=`echo "$inputString" | awk -F: '{print $3}'`
SID=`echo "$inputString" | awk -F: '{print $4}'`
ORACLE_HOME=`echo "$inputString" | awk -F: '{print $5}'`
ORACLE_ROLE=SYSDBA
rc=0
            
# Make sure the ORACLE_HOME is valid
if [ ! -d $ORACLE_HOME ]; then
   echo "Oracle home $ORACLE_HOME does not exist. Exiting....."
   exit 1
fi

#set environment
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

#build connect satement
if [ "$SYS_PASSWORD" = "none" ] ; then
   CONNECT_STRING="/@$SID as $ORACLE_ROLE"
else
   CONNECT_STRING="$SYS_USERID/$SYS_PASSWORD@$SID as $ORACLE_ROLE"
fi

# Attempt to perform a test connection to Oracle to verify that the 
# user id/password and SID work
result=`sqlplus -S /nolog <<EOF
connect $CONNECT_STRING
quit
EOF`
            
# Were we able to connect? All Oracle error codes begin with ORA-
echo $result | grep "ORA-" > /dev/null
if [ $? -eq 0 ] ; then
   rc=1
   echo $result
fi

echo $result | grep "SP2-0306" > /dev/null
if [ $? -eq 0 ] ; then
   rc=1
   echo $result
fi

if [ $rc -eq 0 ] ; then
result=`echo "sqlplus xxxxxx @cr_ts.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@cr_ts.ora
quit  
EOF`
rc=$? 

  echo $result | grep "ORA-01543" > /dev/null
  if [ $? -eq 0 ] ; then
     echo "The Common Event Infrastructure database already exists." 
     exit 20
  fi

fi
            
if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @cr_security.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@cr_security.ora
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
   echo "Create ceidb user for the Common Event Infrastructure database."

result=`sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
CREATE USER ceidb IDENTIFIED BY $USER_PASSWORD default tablespace ceidb_cei_ts_base temporary tablespace ceidb_cei_ts_temp quota unlimited on ceidb_cei_ts_base profile ceidb_cei_profile;
quit  
EOF`

   # send to /dev/null because password will be displayed when error occurred
   echo $result | grep "ORA-" > /dev/null
   if [ $? -eq 0 ] ; then
      rc=1
      echo "Failed to create user ceidb"
      # echo $result will show passwords which may be logged to a file
      #echo $result
   else
      echo $result
   fi
fi

if [ $rc -eq 0 ] ; then
echo "Grant ceidb user resources and ceidb_cei_role"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
GRANT ceidb_cei_role , resource to ceidb;
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "Alter ceidb user default role to ceidb_cei_role"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
ALTER USER ceidb DEFAULT ROLE ceidb_cei_role;
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @cr_tbl.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@cr_tbl.ora
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @ins_metadata.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@ins_metadata.ora
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @cr_ts_catalog.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@cr_ts_catalog.ora
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @cr_tbl_catalog.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@cr_tbl_catalog.ora
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @catalogSeed.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@catalogSeed.ora
quit  
EOF
rc=$? 
fi

if [ $rc -eq 0 ] ; then
echo "sqlplus xxxxxx @cr_stored_procedure.ora"
sqlplus -S /nolog <<EOF
WHENEVER SQLERROR EXIT_FAILURE
connect $CONNECT_STRING
@cr_stored_procedure.ora
quit  
EOF
rc=$? 
fi
               
if [ $rc -eq 0 ] ; then
    echo "The Common Event Infrastructure database is created successfully."
else
    echo "Failed to create the Common Event Infrastructure database."
fi
        
exit $rc

