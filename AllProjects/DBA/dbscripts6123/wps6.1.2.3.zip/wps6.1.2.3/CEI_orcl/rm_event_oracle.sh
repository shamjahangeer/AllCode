#!/bin/sh
#
#  IBM Confidential OCO Source Material
#
#  5724-I63, 5724-H88, 5655-N02, 5733-W70 (C) COPYRIGHT International Business Machines Corp. 2004, 2005
#
#  The source code for this program is not published or otherwise divested
#  of its trade secrets, irrespective of what has been deposited with the
#  U.S. Copyright Office.
#
# ----------------------------------------------------------------------------
# Description:  executes the dbConfigureRm.sh scripts to 
# remove the Common Event Infrastructure database
# Return Codes:  0 for success
#------------------------------------------------------------------------------

#-----------------------------------------
# Ask user for the sysdba userid
#-----------------------------------------
get_sysdba_userid() {
   while true; do
      echo "Enter the user id for a user that has SYSDBA privileges in the Oracle database (normally SYS)."
      read answer
      if [ -n "$answer" ]; then
         sysdba_user=$answer
         break
      else
         echo
         echo "Error: a response is required."
         echo
         continue
      fi
   done
}

#-----------------------------------------
# Ask user for the sysdba password
#-----------------------------------------
get_sysdba_password() {
   while true; do
      echo
      trap 'stty echo;' 0 1 2 3 15
      echo "Enter the password for the user $sysdba_userid that has SYSDBA privileges in the Oracle database. Type none if no password."
      stty -echo
      read answer
      stty echo

      if [ -n "$answer" ]; then
         sysdba_pswd=$answer
         break
      else
         echo
         echo "Error: a response is required."
         echo
         continue
      fi
   done
}

#------------------------------------------------------------------------------
# Ask for the ORACLE_HOME
#------------------------------------------------------------------------------
get_oracle_home() {
   while true; do
      echo "Enter the ORACLE_HOME [$default_oracle_home]"
      read answer
      if [ -n "$answer" ]; then
         oracle_home=$answer
      fi
      break
   done
}

#------------------------------------------------------------------------------
# Ask for the SID
#------------------------------------------------------------------------------
get_sid() {
   while true; do
      echo "Enter the Oracle database name or System Identifier (SID) [$default_sid]"
      read answer
      if [ -n "$answer" ]; then
         sid=$answer
      fi
      break
   done
}

CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

default_sid=SX09N5D7
sid=$default_sid
oracle_home=$default_oracle_home

#call the following subroutine to get the sysdba userid
get_sysdba_userid

#call the following subroutine to get the sysdba password
get_sysdba_password 			

#call to get the sid
get_sid

#call to get the oracle home
get_oracle_home

# Pipe in the db user, password and oracle home
echo "$sysdba_user:$sysdba_pswd:$sid:$oracle_home" | $CURRENT_DIR/dbConfigureRm.sh
rc=$?
			


