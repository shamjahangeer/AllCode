Option Strict Off
Option Explicit On
Module basMain

	Public Const CONNECT_USERID As String = "scd_web"
    Public Const CONNECT_PASSWORD As String = "scd_delivery"

    Public CONNECTION_ESTABLISHED As Boolean = False
    Public CONNECT_DSN As String = ""

    Public objConnectionGbl As New ADODB.Connection

	' Keep a global object on the thread to
	' keep the project from unloading when
	' the last reference to it goes away
	' It has to be public to trick VB into
	' thinking that the thread is not done
	
    Public gt_objDummy As New ThreadDummy
	'UPGRADE_NOTE: Main was upgraded to Main_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Public Sub Main_Renamed()

        ' First line of code should be to instantiate
        ' the dummy class. Be sure to set the Sun Main
        ' as the Startup Object in the project properties.

        gt_objDummy = New ThreadDummy

    End Sub
End Module