Module UpgradeSupport
    'Friend COMSVCSLibGetSecurityCallContextAppObject_definst As New System.EnterpriseServices.SecurityCallContext
    'Friend COMSVCSLibAppServer_definst As New COMSVCSLib.AppServer
End Module